# Western BTR UI and event type fix
- First child and Second child now resolve to Children rule profile.
- Unsupported Other removed from event selector; Education, Relocation and Health added.
- Changing events invalidates previous minute and seconds results.
- Seconds button requires three distinct event dates.
- Seconds API rejects fewer than three events before any search.
- NOTE: Flutter SDK not available locally; compilation not verified.
- NOTE: Western Primary Directions remains partial and method contact scores are not validated probabilities.
