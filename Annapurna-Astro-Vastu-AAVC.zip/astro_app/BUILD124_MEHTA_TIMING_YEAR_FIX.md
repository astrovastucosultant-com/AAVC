# Build124: S.K. Mehta historical event-year correction

## Reported defect
A marriage is known to have occurred in **2008**, but the Mehta tab appeared to show **2018**. The prior screen was only calculating the **current** dasha using `DateTime.now()`; the Tribhagi MD beginning in 2018 was incorrectly easy to mistake for an event date.

## Changes
- Separate current period display from *historical event verification*.
- Add known event year input. A user-provided year such as 2008 is checked day by day against **both** natal Vimshottari and Tribhagi dasha paths using the same birth date and calculated Moon longitude.
- Report best MD/AD/PD-related historical windows, their matched primary AD/PD/Sukshma lords, and missing match evidence.
- Show whether full primary matches exist without forcing a historical event to fit. Do not label MD start years as marriage years.
- Do not modify birth details, horoscope charts, dasha balance, house/planet rules, or other astrology modules.

## Scope limits
- This is a **retrospective diagnostic**, NOT validated automatic wedding-date prediction or full source-level Synchronization/BTR reconstruction.
- Month/day of the wedding and complete source glyph/exception checks are still necessary for exact confirmation.
- No prediction probability is derived from a ratio of matching planets.
- Automated Dart/Flutter compile and execution are **not verified** in this environment. Build after GitHub upload and run `flutter test test/sk_mehta_historical_timing_test.dart`.
