# Western BTR validation fix
- Fixed the past-event date picker: its initial date is now clamped to the allowed range, preventing an assertion when birth date is later than today.
- Retained existing 3-distinct-date validation and event-profile restrictions.
- ZIP member integrity verified; Flutter SDK/Android compile not available in this environment.
- Primary Directions remain incomplete; contact score is heuristic, not accuracy probability.
- Previous stable Build #144 should remain untouched pending CI compile.
