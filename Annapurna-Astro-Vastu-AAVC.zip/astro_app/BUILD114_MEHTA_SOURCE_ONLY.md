# Build114: Strict S.K. Mehta Source-Only Mode

Scope: S.K. Mehta tab only; all other tabs/engines are left in place.

Changes:
- Removed the non-Mehta D1/D10 career fallback from the Mehta tab; no external career taxonomy or evidence-percent scoring in that tab.
- Career category now cross-links only the S.K. Mehta book's profession/business/education-related rules C21, C22, C30, C32, C33, C55, C59, C66 and C84. All existing Mehta career rules remain.
- Missing matched career combinations are labeled **not verified**, never **no occupation**. Auto-unmatched Mehta book rules remain accessible by touch for checking.
- Removed the general Ashtakavarga / Shadvarga strength table from the Mehta page only, not from other app pages.
- Removed traditional remedies without cited Mehta source support from the Mehta tab, replacing rule detail sections with a source limitation statement.
- Removed an app-devised 3/2/2 scoring heuristic that selected natal versus Moon ascendant without an explicit book formula. Natal ascendant remains primary; Moon ascendant is noted for separate Mehta-only confirmation.
- Existing Mehta fundamental, C1-C85, and Mehta event/timing registry remain in this module. Event timing is labeled with its previously supplied Mehta command table rather than being misattributed to the uploaded book.

Validation: ZIP CRC check, source coverage check, file preservation and UI marker checks are **static**. Flutter/Dart SDK is not available here; Android APK compile must be confirmed by GitHub Actions. No claims of medical certainty or event prediction accuracy are made.
