# Build134 — D3 Sarala VII source fidelity

- Started from v1.4.151+151 full Flutter source.
- Original user-owned Sarala 7 final.pdf (18 scanned pages) preserved in docs/source_reference_pdf.
- The PDF's D3 treatment is on pp.2–3, with four main source rule topics.
- Restored source rules SJ7-D3-01..04 with traceable chart conditions / source-only categories.
- Added sibling number, younger/elder sibling, and longevity audit topics per user instruction.
- IMPORTANT: no exact sibling counting formula and no lifespan arithmetic are given on the D3 pages of this PDF. These subjects remain visible and explicitly pending rather than omitted or guessed.
- Existing unrelated modules left intact. No Flutter compiler was available in working container; GitHub build is required.
