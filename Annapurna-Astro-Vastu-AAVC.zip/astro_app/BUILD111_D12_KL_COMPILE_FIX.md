# Build 94 preparation — Annapurna Astro Vastu 1.4.111

GitHub Build #93 (run 38096580720) failed at lib/screens/d12_kl_panel.dart line 116:
`Expected ')' before this` at a doubled `]],` closing an ExpansionTile children list.

Changed `]],` to `],` at the verified `for (final hit in section.value)` / ListTile children block.
Version bumped 1.4.110+110 -> 1.4.111+111.

No other application code was changed. D12 KL reference, 13 checklist tests, % formulas,
existing 59 source rules / 20 examples and other divisional chart modules are unchanged.

VALIDATION:
- ZIP CRC integrity OK, expected changed paths verified.
- Source-level syntax target check OK.
- Full Flutter build/tests NOT run locally: Flutter SDK unavailable.
- Upload stable-named ZIP to GitHub repo root to trigger the next Actions run. A green
  GitHub build is required before calling the new APK ready.
- Run number 94 is expected only if the workflow numbering does not change.
