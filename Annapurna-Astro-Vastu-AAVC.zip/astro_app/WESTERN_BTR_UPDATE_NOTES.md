# Western Timing / BTR — multi-method candidate audit

This incremental update extends the existing Solar Arc-only BTR candidate scoring to all seven implemented contact series (Solar Arc, Secondary, Tertiary-I, Minor, Naibod, 1-degree Symbolic, Converse Secondary). Each candidate now retains per-event/per-method scores and the count of events with at least two method hits. Ranking prioritizes the count of supported events, then the average heuristic score.

**Not complete:** The contact matching is still angle-centric (natal ASC/MC) and does not implement natal house cusp or lord determination. The seven methods are not independent; especially Naibod, 1-degree and Solar Arc can be correlated. This score is not a probability or a birth-time accuracy percentage. Full Primary Directions are not connected to the event search. The Placidus geometry in the source is experimental and has not been cross-validated against reference software. Birth time is sampled at whole-minute offsets, not seconds. Do not describe this as complete eight-method BTR.

Flutter/Dart SDK not installed in the working environment; compilation and on-device verification pending. Keep the last known-good build as backup.
