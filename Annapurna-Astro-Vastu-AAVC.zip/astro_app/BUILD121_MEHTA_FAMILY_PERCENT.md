# Build121 — S.K. Mehta Family Analysis, % display

- **UI:** 12 main result cards now present an overall numeric evidence-balance percentage when testable; individual angle cards include a percentage and bar. The original Result → Horoscope Review → Rule → Source workflow is retained.
- **Formula (app-defined editorial index, NOT from S.K. Mehta):** `round(100*(supporting + 1)/(supporting + cautionary + 2))`; no supporting or cautionary evidence => no numeric percentage. This dampens misleading 100% from a single matched rule.
- **Overall percentage:** arithmetic average of scores for distinct `aspectTopicId` sectors with actual evidence. Duplicated sectors are only counted once; Moon-lagna evidence is displayed independently and not double counted.
- **Interpretation:** % describes comparative **strength of the evaluated house evidence** only; it is not the chance of a marriage, financial profit, illness, business success, birth, or any other event. Debt/loss-related aspects may have a strong *house* without that being a good outcome. The formula is intentionally labelled editorial rather than falsely attributed to the Mehta texts.
- The source-based S.K. Mehta MF-01..MF-10 checks, 27 kinship paths, 12 main topics and previous D7, D10 and D12 modules remain unchanged.
- A single matched favorable rule scores 67 rather than 100; missing evidence returns `null` and is shown as `శాతం: ఆధారం లేదు`, not 0 or 50.
- Unit tests added to `test/mehta_family_interpretation_service_test.dart` for numeric edge cases and scores throughout 27×12 outputs.
- No timing %, clinical diagnostic %, or event probability is asserted; no other authors' rules have been inserted into S.K. Mehta.

## Testing limitations

Python structural inspections and ZIP integrity can be completed locally. Dart/Flutter SDK is not installed in this execution environment, so native Flutter compile, flutter tests, APK generation, and on-device tap tests require GitHub Actions + device validation and must not be labelled passed until run.
