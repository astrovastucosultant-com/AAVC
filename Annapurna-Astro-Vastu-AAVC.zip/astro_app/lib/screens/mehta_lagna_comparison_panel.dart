// Build127: top-of-tab, transparent birth-ASC vs Moon-ASC evidence comparison.
import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/mehta_lagna_comparison_service.dart';

class MehtaLagnaComparisonPanel extends StatelessWidget {
  final AstroChartResult chart;
  const MehtaLagnaComparisonPanel({super.key, required this.chart});

  String _percent(int? p) => p == null ? '—' : '$p%';

  Widget _scoreTile({required String label, required String sign,
    required int? score, required int nHouses}) {
    return Expanded(child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE8D9DB)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(sign, style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 5),
        Text(_percent(score), style: const TextStyle(
          fontSize: 26, fontWeight: FontWeight.w900, color: Color(0xFF6F2139))),
        const SizedBox(height: 4),
        LinearProgressIndicator(
          value: score == null ? 0 : score / 100.0,
          minHeight: 7,
          borderRadius: BorderRadius.circular(5),
          backgroundColor: const Color(0xFFF0E6E7),
          color: const Color(0xFF9B586D),
        ),
        const SizedBox(height: 6),
        Text('పరిశీలన ఆధారాలున్న భావాలు: $nHouses/12',
          style: const TextStyle(fontSize: 11, height: 1.35)),
      ]),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final comparison = MehtaLagnaComparisonService.evaluate(chart);
    return Card(
      color: const Color(0xFFFFF2F1),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('లగ్నం బలమా? చంద్రలగ్నం బలమా?',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          const Text('S.K. Mehta భావబల పరిశీలన ఆధారంగా రెండు లగ్నాల స్వతంత్ర పోలిక',
              style: TextStyle(height: 1.35)),
          const SizedBox(height: 12),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _scoreTile(label: 'జన్మలగ్న బలం', sign: comparison.natalSign,
              score: comparison.natalPercent,
              nHouses: comparison.natalEvidenceHouses),
            const SizedBox(width: 8),
            _scoreTile(label: 'చంద్రలగ్న బలం', sign: comparison.moonSign ?? 'అందుబాటులో లేదు',
              score: comparison.lunarPercent,
              nHouses: comparison.lunarEvidenceHouses),
          ]),
          const SizedBox(height: 12),
          Text(comparison.comparativeNote,
              style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4)),
          const SizedBox(height: 8),
          const Text(
            'జన్మలగ్నం ప్రధాన జాతక సూచికగానే ఉంటుంది. చంద్రలగ్నం స్వతంత్ర ధృవీకరణ. '
            'ఈ రెండు శాతాల మొత్తం 100 కావాల్సిన అవసరం లేదు; ఇవి సంఘటన సంభావ్యతలు కావు.',
            style: TextStyle(fontSize: 12, height: 1.4),
          ),
          const SizedBox(height: 5),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('12 భావాలు — ఏ లగ్నం నుంచి ఏ ఆధారాలు?',
                style: TextStyle(fontWeight: FontWeight.w800)),
            children: comparison.houses.map((house) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${house.house}వ భావం — ${house.topic}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                Text('జన్మలగ్నం: ${_percent(house.natalPercent)} '
                     '(అనుకూల ${house.natalSupporting}, ప్రతికూల ${house.natalCautionary})',
                    style: const TextStyle(fontSize: 12)),
                Text('చంద్రలగ్నం: ${_percent(house.lunarPercent)} '
                     '(అనుకూల ${house.lunarSupporting}, ప్రతికూల ${house.lunarCautionary})',
                    style: const TextStyle(fontSize: 12)),
                const Divider(height: 12),
              ]),
            )).toList(growable: false),
          ),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('శాతం లెక్కించిన విధానం / మూలాధారం',
                style: TextStyle(fontWeight: FontWeight.w800)),
            children: const [
              Text('రెండు లగ్నాల నుంచీ 12 భావాలకు ఒకే 10 గ్రహ–భావ నియమాలను '
                  '(MF-01 నుంచి MF-10) స్వతంత్రంగా పరీక్షిస్తాము. '
                  'స్వాధిపతి, దృష్టి, ఉచ్చ/నీచ, పరివర్తన, 6/8/12 అధిపతి స్థితి '
                  'వంటి అనుకూల–ప్రతికూల ఆధారాలు లెక్కిస్తాము.',
                  style: TextStyle(height: 1.4)),
              SizedBox(height: 8),
              Text('ఒక భావంలో అనుకూల=A, ప్రతికూల=B అయితే యాప్‌లోని '
                  'సవరించిన ఆధార సూచిక (A+1)/(A+B+2) × 100. '
                  'ఆధారాలున్న 12 భావాల సూచికల సగటు ఆ లగ్నం %. '
                  'ఆధారాలు లేని భావాన్ని 0%గా లెక్కించము. '
                  'ఒకే భావాన్ని రెండుసార్లు గణించము. నాలుగు కంటే తక్కువ ఆధారాలున్న '
                  'భావాలైతే లేదా రెండు లగ్నాల తేడా 10 శాతాంకాల కన్నా తక్కువైతే '
                  'నిర్ణయానికి ఆధారాలు సరిపోలేదని చూపుతాము. ఇవి యాప్ ప్రదర్శన '
                  'పరిమితులు; గ్రంథ రచయిత నిర్ణయించిన పరిమితులు కావు.',
                  style: TextStyle(height: 1.4)),
              SizedBox(height: 8),
              Text('మూలం: S.K. Mehta, New Dimensions in Hindu Astrology, '
                  'ముద్రిత పుటలు 26–28, 87–95, 100–109; '
                  'Synchronization of Period, ముద్రిత పుటలు 12–18. '
                  'ఈ శాతం సూత్రం Mehta గారు పేర్కొన్నది కాదు; '
                  'జాతక పరిశీలన కోసం యాప్‌లో రూపొందించిన తులనాత్మక సూచిక మాత్రమే.',
                  style: TextStyle(height: 1.4)),
              SizedBox(height: 12),
            ],
          ),
        ]),
      ),
    );
  }
}
