// Annapurna Astro Vastu — D12 rule matcher
// Source restricted to the supplied Saral Jyotish Part VII, Chapter 9.
// PURE DART: import into a Flutter project and load D12_Rules_Examples.json as an asset.
// The app must calculate/derive fact keys itself. NO ephemeris calculation is done here.
import 'dart:convert';

class D12BookRuleResult {
  final String id;
  final String section;
  final String title;
  final String ifTelugu;
  final String resultTelugu;
  final String polarity;
  final String sourceKind;
  final List<int> printedPages;
  final String caution;
  final String remedyStatus;
  final Map<String, dynamic> raw;

  D12BookRuleResult(Map<String, dynamic> record)
      : raw = record,
        id = record['id'] as String,
        section = record['section'] as String,
        title = record['title'] as String,
        ifTelugu = record['if_te'] as String,
        resultTelugu = record['then_te'] as String,
        polarity = record['polarity'] as String,
        sourceKind = record['source_kind'] as String,
        printedPages = (record['printed_pages'] as List).cast<int>(),
        caution = record['caution'] as String? ?? '',
        remedyStatus = ((record['remedy'] as Map<String, dynamic>?)?
                    ['text_te'] as String?) ?? 'మూల గ్రంథంలో పరిహారం లేదు.';
}

class D12BookRuleEngine {
  final Map<String, dynamic> rulebook;
  D12BookRuleEngine(this.rulebook);

  factory D12BookRuleEngine.fromJsonString(String jsonText) =>
      D12BookRuleEngine(jsonDecode(jsonText) as Map<String, dynamic>);

  static bool matches(Map<String, dynamic> rule, Set<String> facts) {
    final when = rule['when'] as Map<String, dynamic>;
    final all = (when['all'] as List).cast<String>();
    final any = (when['any'] as List).cast<String>();
    return all.every(facts.contains) &&
        (any.isEmpty || any.any(facts.contains));
  }

  // Use with 'facts' generated from correctly computed D12/ KL / Cyclical D12.
  List<D12BookRuleResult> evaluate(Set<String> facts, {String? section}) {
    final records = (rulebook['rules'] as List).cast<Map<String, dynamic>>();
    return records
        .where((r) => (section == null || r['section'] == section) && matches(r, facts))
        .map(D12BookRuleResult.new)
        .toList(growable: false);
  }

  // Example fixture replays document-reported facts and is NOT planetary recalculation.
  List<Map<String, dynamic>> auditExamples() {
    final examples = (rulebook['examples'] as List).cast<Map<String, dynamic>>();
    final records = (rulebook['rules'] as List).cast<Map<String, dynamic>>();
    return examples.map((ex) {
      final facts = (ex['fixture_facts'] as List).cast<String>().toSet();
      final matchingIds = records.where((r) => matches(r, facts))
          .map((r) => r['id'] as String).toSet();
      final required = (ex['expected_rule_ids'] as List).cast<String>();
      final missing = required.where((id) => !matchingIds.contains(id)).toList();
      return {
        'example': ex['id'],
        'assertions': required.length,
        'passed': required.length - missing.length,
        'missing_rules': missing,
      };
    }).toList(growable: false);
  }
}
