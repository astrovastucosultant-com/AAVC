// Annapurna Astro Vastu — Build116
// Source-only family inspection. S.K. Mehta: New Dimensions in Hindu Astrology,
// printed pp. 26–28 (planet dignity), 87–95 (house portfolios / relatives),
// 100–109 (house strength, exchange, aspects), 129–160 (life topics).
// Relative-house arithmetic is an editorial extension where explicitly marked.
// This does NOT manufacture another person's natal chart, diagnoses or dates.
import 'astro_models.dart';
import 'mehta_family_house_service.dart';

enum MehtaFamilyEvidenceType { support, caution, neutral }

enum MehtaFamilyFindingType { supporting, cautionary, mixed, undetermined }

// Build121: editorial evidence balance, NOT a probability, an event prediction,
// or a percentage formula assigned by S.K. Mehta. A one-rule match must not
// display 100%. The two neutral reference counts reduce that distortion.
// No matched strength/weakness evidence => no numeric percentage.
class MehtaFamilyEvidenceIndex {
  const MehtaFamilyEvidenceIndex._();

  static int? percent(int supporting, int cautionary) {
    if (supporting < 0 || cautionary < 0) {
      throw ArgumentError('Evidence counts cannot be negative');
    }
    if (supporting + cautionary == 0) return null;
    return ((supporting + 1) * 100 / (supporting + cautionary + 2)).round();
  }
}

class MehtaFamilyRuleCheck {
  final String id;
  final String rule;
  final String observed;
  final String source;
  final bool matched;
  final MehtaFamilyEvidenceType type;
  const MehtaFamilyRuleCheck({
    required this.id,
    required this.rule,
    required this.observed,
    required this.source,
    required this.matched,
    required this.type,
  });
}

// Editorial evidence angles derived from Mehta's house portfolios.
// These are not separately numbered yogas or guaranteed events in the books.
class MehtaFamilyAngleResult {
  final String title;
  final String purpose;
  final String aspectTopicId;
  final int referenceHouse;
  final String referenceLord;
  final String source;
  final int supporting;
  final int cautionary;
  final int? evidencePercent;
  final MehtaFamilyFindingType type;
  final String interpretation;
  final List<MehtaFamilyRuleCheck> checks;

  const MehtaFamilyAngleResult({
    required this.title, required this.purpose, required this.aspectTopicId,
    required this.referenceHouse, required this.referenceLord,
    required this.source, required this.supporting, required this.cautionary,
    required this.evidencePercent, required this.type, required this.interpretation, required this.checks,
  });
}

class MehtaFamilyMoonReview {
  final int referenceHouse;
  final String lord;
  final int supporting;
  final int cautionary;
  final int? evidencePercent;
  const MehtaFamilyMoonReview({
    required this.referenceHouse, required this.lord,
    required this.supporting, required this.cautionary,
    required this.evidencePercent,
  });
}

class _FamilyAngleSpec {
  final String title;
  final String referenceTopic;
  final String context;
  const _FamilyAngleSpec(this.title, this.referenceTopic, this.context);
}

class MehtaFamilyFinding {
  final MehtaFamilyRelation relation;
  final MehtaFamilyTopic topic;
  final int relationHouse;
  final int targetHouse;
  final String lord;
  final int? lordNatalHouse;
  final int? lordRelativeHouse;
  final List<int> lordOtherHouses;
  final List<PlanetPosition> occupants;
  final List<PlanetPosition> aspecting;
  final List<MehtaFamilyRuleCheck> checks;
  final List<String> relationships;
  final MehtaFamilyFindingType type;
  final int? evidencePercent;
  final int scoredAngleCount;
  final String result;
  final String limitations;
  final List<MehtaFamilyAngleResult> angles;
  final MehtaFamilyMoonReview? moonReview;

  const MehtaFamilyFinding({
    required this.relation,
    required this.topic,
    required this.relationHouse,
    required this.targetHouse,
    required this.lord,
    required this.lordNatalHouse,
    required this.lordRelativeHouse,
    required this.lordOtherHouses,
    required this.occupants,
    required this.aspecting,
    required this.checks,
    required this.relationships,
    required this.type,
    required this.evidencePercent,
    this.scoredAngleCount = 0,
    required this.result,
    required this.limitations,
    this.angles = const <MehtaFamilyAngleResult>[],
    this.moonReview,
  });

  List<MehtaFamilyRuleCheck> get matched =>
      checks.where((x) => x.matched).toList(growable: false);
  List<MehtaFamilyRuleCheck> get favorable => matched
      .where((x) => x.type == MehtaFamilyEvidenceType.support)
      .toList(growable: false);
  List<MehtaFamilyRuleCheck> get unfavorable => matched
      .where((x) => x.type == MehtaFamilyEvidenceType.caution)
      .toList(growable: false);
  String get heading {
    switch (type) {
      case MehtaFamilyFindingType.supporting:
        return 'అనుకూల బల సూచనలు';
      case MehtaFamilyFindingType.cautionary:
        return 'బలహీనత సూచనలు — మినహాయింపులతో';
      case MehtaFamilyFindingType.mixed:
        return 'మిశ్రమ బల సూచనలు';
      case MehtaFamilyFindingType.undetermined:
        return 'నిర్ణయానికి ఆధారాలు తగినంత లేవు';
    }
  }
}

class MehtaFamilyInterpretationService {
  // Mehta three-sign dignity groups (NOT a substituted conventional
  // one-sign exaltation table). These align with the existing S.K. Mehta
  // Combination engine and the source's rashi-group logic.
  static const Map<String, List<int>> exalted = {
    'Sun': [0, 4, 8], 'Moon': [1, 5, 9], 'Mars': [9, 1, 5],
    'Mercury': [10, 2, 6], 'Jupiter': [3, 7, 11],
    'Venus': [11, 3, 7], 'Saturn': [6, 10, 2],
  };
  static const Map<String, List<int>> fallen = {
    'Sun': [6, 10, 2], 'Moon': [3, 7, 11], 'Mars': [3, 7, 11],
    'Mercury': [4, 8, 0], 'Jupiter': [9, 1, 5],
    'Venus': [5, 9, 1], 'Saturn': [0, 4, 8],
  };
  static const Map<String, String> topicReferences = {
    'self': 'New Dimensions పుటలు 87, 100–109',
    'money': 'New Dimensions పుటలు 87–88, 90, 100–109; Synchronization పుట 23–24',
    'younger': 'New Dimensions పుటలు 88, 95; Synchronization పుట 134–135',
    'property': 'New Dimensions పుటలు 88, 95; Synchronization పుటలు 30–31, 135–136',
    'children': 'New Dimensions పుటలు 89, 95, 170–180; Synchronization పుటలు 27–29',
    'service': 'New Dimensions పుటలు 89, 200–217; Synchronization పుట 137',
    'marriage': 'New Dimensions పుటలు 89, 160–169; Synchronization పుటలు 12–22',
    'inheritance': 'New Dimensions పుట 90; New Rules and Combinations పుటలు 142–145',
    'fortune': 'New Dimensions పుటలు 90, 95',
    'profession': 'New Dimensions పుటలు 90, 143–160; Synchronization పుటలు 35–40',
    'elder': 'New Dimensions పుటలు 90, 95',
    'foreign': 'New Dimensions పుటలు 90, 182–185; Synchronization పుటలు 25–27',
  };

  static String _pn(String name) =>
      MehtaFamilyHouseService.planetTelugu[name] ?? name;

  static PlanetPosition? _planet(AstroChartResult chart, String name) {
    for (final item in chart.planets) {
      if (item.name == name) return item;
    }
    return null;
  }

  static int _natalHouse(AstroChartResult chart, int sign) =>
      ((sign - chart.ascendantSignIndex + 12) % 12) + 1;

  static int _relativeHouse(AstroChartResult chart, int sign, int startHouse) =>
      ((sign - MehtaFamilyHouseService.houseSign(chart, startHouse) + 12) % 12) + 1;

  static bool _aspectsSign(PlanetPosition p, int sign) {
    final step = ((sign - p.signIndex + 12) % 12) + 1;
    return (MehtaFamilyHouseService.aspects[p.name] ?? const <int>[])
        .contains(step);
  }

  static bool _inOwnSign(PlanetPosition p) =>
      MehtaFamilyHouseService.signLords[p.signIndex] == p.name;
  static bool _exalted(PlanetPosition p) =>
      (exalted[p.name] ?? const <int>[]).contains(p.signIndex);
  static bool _fallen(PlanetPosition p) =>
      (fallen[p.name] ?? const <int>[]).contains(p.signIndex);

  // Two-way sign exchange: each planet occupies one of the other's own signs.
  static List<String> _exchangePartners(
      AstroChartResult chart, PlanetPosition lord) {
    final result = <String>[];
    for (final candidate in chart.planets) {
      if (candidate.name == lord.name ||
          !MehtaFamilyHouseService.signLords.contains(candidate.name)) {
        continue;
      }
      if (MehtaFamilyHouseService.signLords[lord.signIndex] == candidate.name &&
          MehtaFamilyHouseService.signLords[candidate.signIndex] == lord.name) {
        result.add(candidate.name);
      }
    }
    return result;
  }

  // Build127: one independent house check for comparing natal and Moon ASC.
  // No subtopic averaging, Moon double-counting, or extra predictive rules.
  static MehtaFamilyFinding inspectBasicTopic(
      AstroChartResult chart,
      MehtaFamilyRelation relation,
      MehtaFamilyTopic topic) =>
      _inspectSingle(chart, relation, topic);

  static MehtaFamilyFinding _inspectSingle(
    AstroChartResult chart,
    MehtaFamilyRelation relation,
    MehtaFamilyTopic topic,
  ) {
    final relationHouse = MehtaFamilyHouseService.relativeHouse(relation);
    final targetHouse = MehtaFamilyHouseService.targetHouse(relation, topic);
    final sign = MehtaFamilyHouseService.houseSign(chart, targetHouse);
    final lordName = MehtaFamilyHouseService.signLord(chart, targetHouse);
    final lord = _planet(chart, lordName);
    final occupies = MehtaFamilyHouseService.occupants(chart, targetHouse);
    final watchers = MehtaFamilyHouseService.aspecting(chart, targetHouse);
    final myHouses = <int>[];
    for (var h = 1; h <= 12; h++) {
      if (MehtaFamilyHouseService.signLord(chart, h) == lordName) {
        myHouses.add(_relativeHouse(chart,
            MehtaFamilyHouseService.houseSign(chart, h), relationHouse));
      }
    }
    final checks = <MehtaFamilyRuleCheck>[];
    void add(String id, String rule, String observed, String source,
        bool matched, MehtaFamilyEvidenceType type) {
      checks.add(MehtaFamilyRuleCheck(
        id: id, rule: rule, observed: observed, source: source,
        matched: matched, type: type,
      ));
    }
    const strength = 'New Dimensions పుటలు 100–109, ముఖ్యంగా 102–107';
    const dignity = 'New Dimensions పుటలు 26–28, 96–99';
    final lordHouse = lord == null
        ? null : _relativeHouse(chart, lord.signIndex, relationHouse);
    final lordOwnHouse = lord != null && lord.signIndex == sign;
    add('MF-01', 'ఆ భావంలో తన అధిపతి ఉండటం',
        lordOwnHouse ? '${_pn(lordName)} అదే భావంలో ఉన్నాడు' :
        '${_pn(lordName)} ఆ భావంలో లేడు', strength,
        lordOwnHouse, MehtaFamilyEvidenceType.support);

    final ownAspect = lord != null && !lordOwnHouse && _aspectsSign(lord, sign);
    add('MF-02', 'భావాన్ని స్వాధిపతి దృష్టించడం',
        ownAspect ? '${_pn(lordName)} స్వభావాన్ని దృష్టిస్తున్నాడు' :
        'స్వాధిపతి దృష్టి కనిపించలేదు', strength,
        ownAspect, MehtaFamilyEvidenceType.support);

    final exaltOccupants = occupies.where(_exalted).toList();
    add('MF-03', 'ఉచ్చస్థితి గ్రహం భావంలో ఉండటం',
        exaltOccupants.isEmpty ? 'ఈ భావంలో ఉచ్చగ్రహం లేదు' :
        '${exaltOccupants.map((p) => _pn(p.name)).join(' / ')} ఉచ్చంలో ఉంది',
        strength, exaltOccupants.isNotEmpty, MehtaFamilyEvidenceType.support);

    final exaltWatchers = watchers.where(_exalted).toList();
    add('MF-04', 'ఉచ్చస్థితి గ్రహదృష్టి భావానికి రావటం',
        exaltWatchers.isEmpty ? 'ఉచ్చగ్రహ దృష్టి లేదు' :
        '${exaltWatchers.map((p) => _pn(p.name)).join(' / ')} ఉచ్చ దృష్టి',
        strength, exaltWatchers.isNotEmpty, MehtaFamilyEvidenceType.support);

    final exchanged = lord == null ? <String>[] : _exchangePartners(chart, lord);
    add('MF-05', 'భావాధిపతి మరో గ్రహంతో రాశి పరివర్తన',
        exchanged.isEmpty ? 'పరివర్తన లేదు' :
        '${_pn(lordName)} ⇄ ${exchanged.map(_pn).join(' / ')} పరివర్తన',
        'New Dimensions పుటలు 103–105',
        exchanged.isNotEmpty, MehtaFamilyEvidenceType.support);

    final lordGood = lord != null && (_inOwnSign(lord) || _exalted(lord));
    add('MF-06', 'భావాధిపతి స్వక్షేత్రం లేదా ఉచ్చంలో ఉండటం',
        lord == null ? 'అధిపతి గ్రహ సమాచారం లేదు' :
        lordGood ? '${_pn(lordName)} ${_exalted(lord) ? 'ఉచ్చంలో' : 'స్వక్షేత్రంలో'}' :
        '${_pn(lordName)} ఉచ్చ/స్వక్షేత్రంలో లేడు',
        dignity, lordGood, MehtaFamilyEvidenceType.support);

    final lordDusthana = lordHouse != null && const <int>[6, 8, 12].contains(lordHouse);
    add('MF-07', 'బంధువు లగ్నం నుంచి భావాధిపతి 6/8/12లో ఉండటం',
        lordHouse == null ? 'అధిపతి స్థానం అందుబాటులో లేదు' :
        '${_pn(lordName)} బంధువు లగ్నం నుంచి ${lordHouse}వ భావంలో ఉన్నాడు',
        'New Dimensions పుటలు 105–107',
        lordDusthana, MehtaFamilyEvidenceType.caution);

    final lordInFall = lord != null && _fallen(lord);
    add('MF-08', 'భావాధిపతి నీచస్థితి',
        lordInFall ? '${_pn(lordName)} Mehta ఉచ్చ–నీచ పట్టిక ప్రకారం నీచంలో ఉన్నాడు' :
        'అధిపతికి నీచస్థితి గుర్తించలేదు',
        dignity, lordInFall, MehtaFamilyEvidenceType.caution);

    final fallOccupants = occupies.where(_fallen).toList();
    add('MF-09', 'నీచగ్రహం ఆ భావంలో ఉండటం',
        fallOccupants.isEmpty ? 'నీచగ్రహ నివాసం కనిపించలేదు' :
        '${fallOccupants.map((p) => _pn(p.name)).join(' / ')} నీచగ్రహ ప్రభావం',
        'New Dimensions పుటలు 106–109',
        fallOccupants.isNotEmpty, MehtaFamilyEvidenceType.caution);

    final fallWatchers = watchers.where(_fallen).toList();
    add('MF-10', 'నీచగ్రహ దృష్టి ఆ భావానికి రావటం',
        fallWatchers.isEmpty ? 'నీచగ్రహ దృష్టి కనిపించలేదు' :
        '${fallWatchers.map((p) => _pn(p.name)).join(' / ')} నీచగ్రహ దృష్టి',
        'New Dimensions పుటలు 106–109',
        fallWatchers.isNotEmpty, MehtaFamilyEvidenceType.caution);

    final relationships = <String>[];
    for (final p in occupies) {
      final names = <String>[];
      if (_inOwnSign(p)) names.add('స్వక్షేత్రం');
      if (_exalted(p)) names.add('ఉచ్చ');
      if (_fallen(p)) names.add('నీచ');
      if (p.retrograde) names.add('వక్ర');
      relationships.add('${_pn(p.name)} — ${names.isEmpty ? 'సాధారణ రాశి స్థితి' : names.join(', ')}; బంధువు లగ్నం నుంచి ${_relativeHouse(chart, p.signIndex, relationHouse)}వ భావం');
    }
    for (final p in watchers) {
      relationships.add('${_pn(p.name)} — ${_relativeHouse(chart, p.signIndex, relationHouse)}వ భావం నుంచి ${topic.offset}వ భావానికి Mehta దృష్టి');
    }
    for (final name in exchanged) {
      relationships.add('${_pn(lordName)}–${_pn(name)} పరివర్తన: రెండు అధిపత్యాల పోర్ట్‌ఫోలియోలను కలిసి చూడాలి');
    }
    if (lord != null) {
      relationships.add('భావాధిపతి ${_pn(lordName)} — మూల జాతక ${_natalHouse(chart, lord.signIndex)}వ భావం; బంధువు ${lordHouse}వ భావం; ${MehtaFamilyHouseService.signs[lord.signIndex]} రాశి; ${lord.degreesInSign.toStringAsFixed(2)}°; ${lord.retrograde ? 'వక్ర' : 'మార్గి'}');
    }
    final good = checks.where((x) => x.matched && x.type == MehtaFamilyEvidenceType.support).length;
    final caution = checks.where((x) => x.matched && x.type == MehtaFamilyEvidenceType.caution).length;
    final findingType = good > 0 && caution > 0
        ? MehtaFamilyFindingType.mixed
        : good > 0 ? MehtaFamilyFindingType.supporting
        : caution > 0 ? MehtaFamilyFindingType.cautionary
        : MehtaFamilyFindingType.undetermined;
    final heading = switch (findingType) {
      MehtaFamilyFindingType.supporting =>
        'ఈ అంశానికి గ్రంథంలోని భావబలాన్ని సూచించే సంబంధాలు కనిపించాయి. ఇవి అనుకూల ఆధారాలు; వ్యక్తిగత సంఘటన జరిగిందని నిర్ధారణ కాదు.',
      MehtaFamilyFindingType.cautionary =>
        'ఈ అంశానికి బలహీనతను సూచించే సంబంధాలు కనిపించాయి. మినహాయింపులు, ఇతర గ్రహసంబంధాలు, గత సంఘటనలు పరీక్షించకుండా ప్రతికూల ఫలితాన్ని ఖరారు చేయరాదు.',
      MehtaFamilyFindingType.mixed =>
        'ఈ అంశానికి అనుకూల, ప్రతికూల సూచనలు రెండూ ఉన్నాయి. ఏది బలంగా పనిచేస్తుందో గ్రంథంలోని ఇతర సంబంధాలు, సంఘటనల నేపథ్యం, దశలతో నిర్ణయించాలి.',
      MehtaFamilyFindingType.undetermined =>
        'ఈ అంశానికి పరీక్షించిన ప్రత్యేక బల/బలహీనత నియమాలు సరిపోలలేదు. అందువల్ల ఈ అంశం లేదని లేదా ఫలితం రాదని అర్థం కాదు.',
    };
    return MehtaFamilyFinding(
      relation: relation, topic: topic, relationHouse: relationHouse,
      targetHouse: targetHouse, lord: lordName,
      lordNatalHouse: lord == null ? null : _natalHouse(chart, lord.signIndex),
      lordRelativeHouse: lordHouse,
      lordOtherHouses: myHouses,
      occupants: occupies, aspecting: watchers, checks: checks,
      relationships: relationships, type: findingType,
      evidencePercent: MehtaFamilyEvidenceIndex.percent(good, caution),
      result: heading,
      limitations: 'ఈ పరిశీలన Mehta గ్రంథంలోని భావబలం/అధిపత్యం/దృష్టి నియమాలపై ఆధారపడినది. ఇతర ప్రత్యేక కాంబినేషన్లు, నవాంశం వంటి వేరే పద్ధతులు ఇక్కడ కలపలేదు. దశ–అంతర్దశ / Synchronization ధృవీకరణ లేకుండా సంఘటన తేదీ ఇవ్వము. వైద్య సమస్య, మరణం, వ్యక్తిత్వం, కుటుంబ సంబంధాలపై నిర్ధారిత తీర్పుగా పరిగణించరాదు.',
    );
  }

  // The topic portfolios follow the user's three Mehta volumes. Subtopics
  // are linked by relative-house arithmetic, not extra Mehta combinations.
  // Their evidence is presented independently; no invented probability %.
  static const Map<String, List<_FamilyAngleSpec>> _anglePlan = {
    'self': [
      _FamilyAngleSpec('శరీరబలం / వ్యక్తిగత స్థితి', 'self', 'మొదటి భావం ద్వారా స్థైర్యం, సాధారణ స్థితి'),
      _FamilyAngleSpec('మానసిక ప్రశాంతత / గృహ జీవనం', 'property', 'నాలుగో భావానికి అనుసంధానమైన కుటుంబ వాతావరణం'),
      _FamilyAngleSpec('ధన భద్రత', 'money', 'రెండో భావం ద్వారా నిల్వలు'),
      _FamilyAngleSpec('పని ద్వారా గుర్తింపు', 'profession', 'పదవ భావం ద్వారా ప్రజా/వృత్తి స్థితి'),
      _FamilyAngleSpec('లాభాలు / సహకారం', 'elder', 'పదకొండవ భావం ద్వారా లాభం'),
    ],
    'money': [
      _FamilyAngleSpec('ధన నిల్వలు / కుటుంబ వనరులు', 'money', 'రెండో భావం: సంపాదించిన ధనం నిలిపే స్థితి'),
      _FamilyAngleSpec('సంపాదనకు వృత్తి ఆధారం', 'profession', 'పదవ భావం: ఉపాధి/వ్యాపారం నుంచి సంపాదన'),
      _FamilyAngleSpec('ఆదాయ లాభాలు', 'elder', 'పదకొండవ భావం: లాభ ప్రవాహం'),
      _FamilyAngleSpec('ఇల్లు / స్థిరాస్తి', 'property', 'నాలుగో భావం: నివాసం, స్థిరాస్తి'),
      _FamilyAngleSpec('వారసత్వం / ఉమ్మడి వనరులు', 'inheritance', 'ఎనిమిదో భావం: వారసత్వం/ఇతరుల వనరులు'),
      _FamilyAngleSpec('అప్పులు / వివాదాలు', 'service', 'ఆరో భావం: అప్పులు, వ్యాజ్యాలు, ప్రతిబంధకాలు'),
      _FamilyAngleSpec('వ్యయం / నిల్వలపై ఒత్తిడి', 'foreign', 'పన్నెండవ భావం: వ్యయం, విదేశీ ఖర్చులు'),
    ],
    'younger': [
      _FamilyAngleSpec('చిన్న సహోదరుల సంబంధం', 'younger', 'మూడవ భావం ద్వారా సంబంధిత బంధుత్వం'),
      _FamilyAngleSpec('కృషి / ధైర్యం', 'younger', 'మూడవ భావం: ప్రయత్న సామర్థ్యం'),
      _FamilyAngleSpec('తోడ్పాటు / లాభం', 'elder', 'పదకొండవ భావం: సహకారం/ఫలితాలు'),
      _FamilyAngleSpec('సంబంధాల అనుకూలత', 'marriage', 'ఏడవ భావం: పరస్పర అవగాహన'),
    ],
    'property': [
      _FamilyAngleSpec('తల్లి / గృహ సౌఖ్యం', 'property', 'నాలుగో భావం: తల్లి, ఇల్లు, సుఖం'),
      _FamilyAngleSpec('స్థిరాస్తికి ధనవనరులు', 'money', 'రెండో భావం: ఆస్తికి నిధులు'),
      _FamilyAngleSpec('ఆస్తి సంపాదన మూలం', 'profession', 'పదవ భావం: ఉపాధి ద్వారా స్థిరాస్తి'),
      _FamilyAngleSpec('వారసత్వ ఆస్తి', 'inheritance', 'ఎనిమిదో భావం: వారసత్వ అర్హతకు సూచనలు'),
      _FamilyAngleSpec('రుణాలు / ఆస్తి వివాదాలు', 'service', 'ఆరో భావం: అప్పులు, వివాదాలు'),
    ],
    'children': [
      _FamilyAngleSpec('సంతానం / విద్య', 'children', 'ఐదవ భావం: సంతానం, నేర్చుకునే అంశాలు'),
      _FamilyAngleSpec('విద్యతో వృత్తి సంబంధం', 'profession', 'పదవ భావం: వృత్తిలో విద్య వినియోగం'),
      _FamilyAngleSpec('ఉన్నత అధ్యయన అవకాశాలు', 'fortune', 'తొమ్మిదవ భావం: ఉన్నత అధ్యయనం, ధర్మం'),
      _FamilyAngleSpec('సంతాన గృహ సౌఖ్యం', 'property', 'నాలుగో భావం: కుటుంబ వాతావరణం'),
      _FamilyAngleSpec('ఖర్చులు / విద్య ఆటంకాలు', 'foreign', 'పన్నెండవ భావం: వ్యయం'),
    ],
    'service': [
      _FamilyAngleSpec('సేవ / పోటీ / వివాదం', 'service', 'ఆరో భావం: సేవ, పోటీ, వివాదాలు'),
      _FamilyAngleSpec('ఉపాధి / స్థానం', 'profession', 'పదవ భావం: ఉద్యోగ/వృత్తి స్థితి'),
      _FamilyAngleSpec('ఆదాయ భద్రత', 'elder', 'పదకొండవ భావం: ఉద్యోగం ద్వారా లాభం'),
      _FamilyAngleSpec('స్వీయ బలం', 'self', 'మొదటి భావం: సాధారణ శక్తి'),
      _FamilyAngleSpec('చికిత్స / ఇతర వ్యయం', 'foreign', 'పన్నెండవ భావం: ఖర్చులు'),
    ],
    'marriage': [
      _FamilyAngleSpec('జీవిత భాగస్వామ్యం', 'marriage', 'ఏడవ భావం: వైవాహిక సంబంధం'),
      _FamilyAngleSpec('కుటుంబ అనుబంధం', 'money', 'రెండో భావం: కుటుంబం/సంయుక్త వనరులు'),
      _FamilyAngleSpec('గృహ ప్రశాంతత', 'property', 'నాలుగో భావం: గృహ జీవనం'),
      _FamilyAngleSpec('సంతాన అంశం', 'children', 'ఐదవ భావం: సంతానం'),
      _FamilyAngleSpec('భాగస్వామ్య వ్యవహారాలు', 'profession', 'పదవ భావం: వృత్తిపై కుటుంబ ప్రభావం'),
      _FamilyAngleSpec('వివాదాలు / అడ్డంకులు', 'service', 'ఆరో భావం: సంబంధిత విభేదాలు'),
    ],
    'inheritance': [
      _FamilyAngleSpec('వారసత్వ / ఉమ్మడి ధనం', 'inheritance', 'ఎనిమిదవ భావం: వారసత్వం'),
      _FamilyAngleSpec('స్థిరాస్తి', 'property', 'నాలుగో భావం: భూమి, నివాసం'),
      _FamilyAngleSpec('కుటుంబ ధనం', 'money', 'రెండో భావం: కుటుంబ నిల్వలు'),
      _FamilyAngleSpec('పత్రాలు / వివాదాలు', 'service', 'ఆరో భావం: వారసత్వ తగాదాలు'),
      _FamilyAngleSpec('వ్యయం', 'foreign', 'పన్నెండవ భావం: ఖర్చుల ఒత్తిడి'),
    ],
    'fortune': [
      _FamilyAngleSpec('భాగ్య / ధర్మ సంబంధం', 'fortune', 'తొమ్మిదో భావం: ధర్మం, అదృష్టసంబంధ అంశం'),
      _FamilyAngleSpec('ఉన్నత విద్య', 'children', 'ఐదవ భావం: అభ్యాసం, బుద్ధి'),
      _FamilyAngleSpec('సామాజిక / వృత్తి స్థాయి', 'profession', 'పదవ భావం: స్థానం'),
      _FamilyAngleSpec('ఫలించే లాభాలు', 'elder', 'పదకొండవ భావం: లాభం'),
      _FamilyAngleSpec('దూర ప్రయాణం', 'foreign', 'పన్నెండో భావం: దూర ప్రాంత సంబంధం'),
    ],
    'profession': [
      _FamilyAngleSpec('ప్రధాన వృత్తి / స్థాయి', 'profession', 'పదవ భావం: పని, వృత్తి, హోదా'),
      _FamilyAngleSpec('చదువు / నైపుణ్య సంబంధం', 'children', 'ఐదవ భావం: విద్య, నైపుణ్యం'),
      _FamilyAngleSpec('పని ద్వారా లాభం', 'elder', 'పదకొండవ భావం: వృత్తి ఆదాయం'),
      _FamilyAngleSpec('సేవా రంగ సంబంధం', 'service', 'ఆరో భావం: ఉద్యోగ/సేవా సంబంధం'),
      _FamilyAngleSpec('వ్యాపార / భాగస్వామ్య సంబంధం', 'marriage', 'ఏడవ భావం: వ్యాపార భాగస్వామ్యం'),
      _FamilyAngleSpec('సంపాదన / నిల్వ', 'money', 'రెండవ భావం: వృత్తి ద్వారా ధనభద్రత'),
    ],
    'elder': [
      _FamilyAngleSpec('పెద్ద సహోదరులు', 'elder', 'పదకొండో భావం: పెద్ద సహోదరుల సంబంధం'),
      _FamilyAngleSpec('లాభప్రాప్తి', 'elder', 'పదకొండో భావం: లాభం'),
      _FamilyAngleSpec('ధననిల్వలు', 'money', 'రెండో భావం: ఆర్థిక నిల్వ'),
      _FamilyAngleSpec('వృత్తి ఆదాయం', 'profession', 'పదవ భావం: సంపాదన మూలం'),
      _FamilyAngleSpec('పరస్పర తోడ్పాటు', 'younger', 'మూడవ భావం: బంధువుల మధ్య ప్రయత్నాలు'),
    ],
    'foreign': [
      _FamilyAngleSpec('విదేశీ సంబంధం / వ్యయం', 'foreign', 'పన్నెండో భావం: విదేశం, ఖర్చులు'),
      _FamilyAngleSpec('దూర ప్రయాణం / భాగ్యం', 'fortune', 'తొమ్మిదో భావం: దూర ప్రయాణ అంశం'),
      _FamilyAngleSpec('విదేశీ ఉపాధి', 'profession', 'పదవ భావం: విదేశాల్లో వృత్తి సంబంధం'),
      _FamilyAngleSpec('ప్రయాణ ఖర్చు', 'money', 'రెండో భావం: ధన వ్యయం భరించే ఆధారం'),
      _FamilyAngleSpec('నివాస స్థిరత్వం', 'property', 'నాలుగో భావం: ఇల్లు/నివాసం'),
    ],
  };

  static MehtaFamilyFinding inspect(
    AstroChartResult chart,
    MehtaFamilyRelation relation,
    MehtaFamilyTopic topic,
  ) {
    final main = _inspectSingle(chart, relation, topic);
    final angles = <MehtaFamilyAngleResult>[];
    for (final item in _anglePlan[topic.id] ?? const <_FamilyAngleSpec>[]) {
      final referenceTopic = MehtaFamilyHouseService.topics
          .firstWhere((t) => t.id == item.referenceTopic);
      final sub = _inspectSingle(chart, relation, referenceTopic);
      final positive = sub.favorable.length;
      final adverse = sub.unfavorable.length;
      final String verdict;
      final stressAngle = item.title.contains('అప్పులు') ||
          item.title.contains('వ్యయం') || item.title.contains('వివాదాలు') ||
          item.title.contains('ఖర్చు') || item.title.contains('ఆటంకాలు');
      if (stressAngle && positive > 0 && adverse == 0) {
        verdict = 'సంబంధిత భావానికి బలం కనిపించింది. ఇది అప్పులు, వివాదాలు లేదా ఖర్చులు మంచివని చెప్పే ఫలితం కాదు; ఆ అంశం చురుకుగా ఉండవచ్చన్న భావ పరిశీలన మాత్రమే.';
      } else if (positive > 0 && adverse > 0) {
        verdict = 'అనుకూల $positive, ప్రతికూల $adverse గ్రహబల సూచనలు కలిసి ఉన్నాయి. ఒక్క సంబంధంతో నిర్ధారణ చేయరాదు.';
      } else if (positive > 0) {
        verdict = 'ఈ అంశానికి అనుకూల గ్రహబల సూచనలు $positive కనిపించాయి; జరిగిన సంఘటన అని అర్థం కాదు.';
      } else if (adverse > 0) {
        verdict = 'ఈ అంశంలో ప్రతికూల/ఆటంక సూచనలు $adverse కనిపించాయి; దాని ఫలితాన్ని ఖచ్చితంగా ప్రకటించరాదు.';
      } else {
        verdict = 'ప్రత్యేక అనుకూల/ప్రతికూల బల నియమం సరిపోలలేదు; ఫలితం లేదని అర్థం కాదు.';
      }
      angles.add(MehtaFamilyAngleResult(
        title: item.title,
        purpose: item.context,
        aspectTopicId: item.referenceTopic,
        referenceHouse: sub.targetHouse,
        referenceLord: sub.lord,
        source: topicReferences[item.referenceTopic] ?? 'New Dimensions — Houses and Portfolios',
        supporting: positive,
        cautionary: adverse,
        evidencePercent: MehtaFamilyEvidenceIndex.percent(positive, adverse),
        type: sub.type,
        interpretation: verdict,
        checks: sub.checks,
      ));
    }
    // Moon lagna is a separate verification, NOT an extra confirmed yoga
    // and not automatically counted twice in the principal conclusion.
    MehtaFamilyMoonReview? lunar;
    final moon = _planet(chart, 'Moon');
    if (moon != null) {
      final moonChart = AstroChartResult(
        julianDay: chart.julianDay,
        ayanamsaDegrees: chart.ayanamsaDegrees,
        ascendantLongitude: moon.longitude,
        planets: chart.planets,
        engineVersion: chart.engineVersion,
      );
      final check = _inspectSingle(moonChart, relation, topic);
      lunar = MehtaFamilyMoonReview(
        referenceHouse: check.targetHouse,
        lord: check.lord,
        supporting: check.favorable.length,
        cautionary: check.unfavorable.length,
        evidencePercent: check.evidencePercent,
      );
    }
    // Count each aspect topic at most once: some portfolios repeat the same
    // house (e.g. sibling and income can both refer to the 11th house).
    // The lunar cross-check is independent and never counted again here.
    final distinctEvidence = <String, int>{};
    for (final angle in angles) {
      if (angle.evidencePercent != null) {
        distinctEvidence.putIfAbsent(
          angle.aspectTopicId, () => angle.evidencePercent!);
      }
    }
    final int? totalPercent = distinctEvidence.isEmpty
        ? null
        : (distinctEvidence.values.reduce((a, b) => a + b) /
            distinctEvidence.length).round();

    // Distinct sector checks are evidence categories, never a success %.
    final positiveAngles = angles.where((a) => a.supporting > 0).length;
    final cautionAngles = angles.where((a) => a.cautionary > 0).length;
    final combinedType = positiveAngles > 0 && cautionAngles > 0
        ? MehtaFamilyFindingType.mixed
        : positiveAngles > 0
            ? MehtaFamilyFindingType.supporting
            : cautionAngles > 0
                ? MehtaFamilyFindingType.cautionary
                : MehtaFamilyFindingType.undetermined;
    final summaryStart = switch (combinedType) {
      MehtaFamilyFindingType.supporting =>
        'ఈ అంశంలోని ఉపవిషయాల్లో సహాయక గ్రహబల సంబంధాలు కనిపించాయి.',
      MehtaFamilyFindingType.cautionary =>
        'ఈ అంశంలోని ఉపవిషయాల్లో ఆటంకాన్ని సూచించే గ్రహబల సంబంధాలు కనిపించాయి.',
      MehtaFamilyFindingType.mixed =>
        'ఈ అంశంలో సహాయక, ప్రతిబంధక గ్రహసంబంధాలు రెండూ కనిపించాయి.',
      MehtaFamilyFindingType.undetermined =>
        'ఈ అంశానికి పరీక్షించిన ప్రత్యేక బల/బలహీనత కాంబినేషన్లు సరిపోలలేదు.',
    };
    final summaries = angles.take(4).map((a) =>
        '${a.title}: ${a.supporting > 0 && a.cautionary > 0 ? 'మిశ్రమ ఆధారాలు' : a.supporting > 0 ? 'అనుకూల ఆధారాలు' : a.cautionary > 0 ? 'జాగ్రత్త సూచనలు' : 'నిర్దిష్ట ఆధారం లేదు'}').join(' • ');
    final combined = '$summaryStart ${angles.length} ఉపాంశాలను విడివిడిగా పరిశీలించాం. $summaries. ఇవి Mehta భావబల సూచనలే; నిర్దిష్ట సంఘటన జరిగిందని నిర్ధారణ కాదు.';
    return MehtaFamilyFinding(
      relation: main.relation,
      topic: main.topic,
      relationHouse: main.relationHouse,
      targetHouse: main.targetHouse,
      lord: main.lord,
      lordNatalHouse: main.lordNatalHouse,
      lordRelativeHouse: main.lordRelativeHouse,
      lordOtherHouses: main.lordOtherHouses,
      occupants: main.occupants,
      aspecting: main.aspecting,
      checks: main.checks,
      relationships: main.relationships,
      type: combinedType,
      evidencePercent: totalPercent,
      scoredAngleCount: distinctEvidence.length,
      result: combined,
      limitations: main.limitations,
      angles: angles,
      moonReview: lunar,
    );
  }

  static List<MehtaFamilyFinding> allTopics(
      AstroChartResult chart, MehtaFamilyRelation relation) =>
      MehtaFamilyHouseService.topics
          .map((topic) => inspect(chart, relation, topic)).toList(growable: false);
}
