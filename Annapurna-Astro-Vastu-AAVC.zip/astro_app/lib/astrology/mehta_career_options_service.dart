import 'astro_models.dart';

/// Mehta-only career portfolio screening, not a predictive certainty or a D10
/// calculation. Individual occupation labels are modern examples derived from
/// the planetary/house portfolios in S.K. Mehta, New Dimensions in Hindu
/// Astrology, printed pp. 87–95, and are NOT author-quoted rules.
enum MehtaCareerMode { business, service }

class MehtaCareerOption {
  final String name;
  final String planet;
  final String planetaryReason;
  final List<String> houseReasons;
  final String source;
  const MehtaCareerOption({
    required this.name,
    required this.planet,
    required this.planetaryReason,
    required this.houseReasons,
    required this.source,
  });
}

class MehtaCareerOptionsService {
  MehtaCareerOptionsService._();
  static const _lords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];
  static const _planetNames = <String, String>{
    'Sun':'రవి', 'Moon':'చంద్రుడు', 'Mars':'కుజుడు',
    'Mercury':'బుధుడు', 'Jupiter':'గురువు',
    'Venus':'శుక్రుడు', 'Saturn':'శని',
  };
  static const _portfolio = <String, String>{
    'Sun':'పాలన, ప్రభుత్వ బాధ్యతలు, నాయకత్వం',
    'Moon':'ఆహార, సంరక్షణ, రవాణా, ప్రజా సేవలు',
    'Mars':'యంత్రాలు, సాంకేతిక పని, నిర్మాణం, రక్షణ సేవలు',
    'Mercury':'వాణిజ్యం, లెక్కలు, రచన, సమాచార మార్పిడి',
    'Jupiter':'విద్య, బోధన, న్యాయ/సలహా పనులు',
    'Venus':'దుస్తులు, అందం, కళలు, అలంకరణ',
    'Saturn':'పరిశ్రమలు, నిర్మాణం, శ్రమ నిర్వహణ',
  };

  // These are illustrative contemporary occupation choices based *only* on
  // Mehta's planetary portfolios. None is asserted to be a literal named
  // Mehta combination or to be a standalone verified horoscope result.
  static const _businessRoles = <String, List<String>>{
    'Sun': ['పరిపాలనా కన్సల్టెన్సీ', 'ఈవెంట్ / సంస్థల నిర్వహణ సేవలు', 'పబ్లిక్ రిలేషన్స్ సేవలు'],
    'Moon': ['డెయిరీ / పాల ఉత్పత్తుల వ్యాపారం', 'హోటల్ / ఆహార సేవలు', 'రవాణా / ట్రావెల్ సేవలు'],
    'Mars': ['మెకానికల్ రిపేర్ వర్క్‌షాప్', 'ఇంజినీరింగ్ పరికరాల సరఫరా', 'బిల్డింగ్ హార్డ్‌వేర్ వ్యాపారం'],
    'Mercury': ['రిటైల్ / హోల్‌సేల్ ట్రేడింగ్', 'అకౌంటింగ్ / బుక్‌కీపింగ్ సేవలు', 'పుస్తకాలు / స్టేషనరీ వ్యాపారం', 'ప్రకటన / సమాచార సేవలు'],
    'Jupiter': ['ట్యూషన్ / శిక్షణ కేంద్రం', 'విద్యా పుస్తకాల ప్రచురణ / విక్రయం', 'విద్యా / నిర్వహణ కన్సల్టెన్సీ'],
    'Venus': ['బట్టల బుటిక్ / డిజైనర్ దుస్తులు', 'బ్యూటీ / కాస్మెటిక్స్ వ్యాపారం', 'అలంకరణ / ఇంటీరియర్ సేవలు', 'కళా కార్యక్రమాల నిర్వహణ'],
    'Saturn': ['బిల్డింగ్ మెటీరియల్స్ వ్యాపారం', 'చిన్న తయారీ పరిశ్రమ / వర్క్‌షాప్', 'కట్టడాల నిర్వహణ సేవలు'],
  };
  static const _serviceRoles = <String, List<String>>{
    'Sun': ['ప్రభుత్వ పరిపాలన ఉద్యోగాలు', 'సంస్థల నిర్వాహక బాధ్యతలు', 'పబ్లిక్ అడ్మినిస్ట్రేషన్ సేవలు'],
    'Moon': ['ఆరోగ్య సంరక్షణ సహాయక సేవలు', 'హోటల్ / హాస్పిటాలిటీ ఉద్యోగాలు', 'రవాణా / టూరిజం నిర్వహణ'],
    'Mars': ['ఇంజినీరింగ్ / టెక్నీషియన్ ఉద్యోగాలు', 'పోలీసు / అగ్నిమాపక సేవలు', 'మెకానికల్ / నిర్వహణ ఉద్యోగాలు'],
    'Mercury': ['అకౌంటెంట్ / ఆడిట్ సహాయక ఉద్యోగాలు', 'బ్యాంకింగ్ / కార్యాలయ ఉద్యోగాలు', 'రచన / మీడియా / కమ్యూనికేషన్ ఉద్యోగాలు'],
    'Jupiter': ['ఉపాధ్యాయ / అధ్యాపక ఉద్యోగాలు', 'విద్యా పరిపాలన / సలహా ఉద్యోగాలు', 'న్యాయవృత్తి / న్యాయసహాయక సేవలు'],
    'Venus': ['ఫ్యాషన్ / దుస్తుల డిజైన్ ఉద్యోగాలు', 'ఆర్ట్స్ / సంగీత / వినోద రంగ ఉద్యోగాలు', 'అలంకరణ / డిజైన్ ఉద్యోగాలు'],
    'Saturn': ['పారిశ్రామిక పర్యవేక్షణ ఉద్యోగాలు', 'నిర్మాణ / మౌలిక సదుపాయాల సేవలు', 'ప్రొడక్షన్ / మెయింటెనెన్స్ ఉద్యోగాలు'],
  };

  static String planetTelugu(String english) => _planetNames[english] ?? english;
  static String portfolio(String planet) => _portfolio[planet] ?? 'మూలం మరింత పరిశీలించాలి';

  static int _houseSign(AstroChartResult chart, int house) =>
      (chart.ascendantSignIndex + house - 1) % 12;

  static String houseLord(AstroChartResult chart, int house) =>
      _lords[_houseSign(chart, house)];

  static List<MehtaCareerOption> evaluate(
      AstroChartResult chart, MehtaCareerMode mode) {
    // Use Mehta's house portfolios: seventh/business, sixth/service,
    // tenth/profession, second/money, eleventh/gains. No D10, BPHS,
    // Ashtakavarga, or source-unverified profession scores are imported.
    final primaryHouses = mode == MehtaCareerMode.business
        ? const <int>[7, 10]
        : const <int>[10, 6];
    final secondaryHouses = mode == MehtaCareerMode.business
        ? const <int>[2, 11]
        : const <int>[11, 2];
    final houseEvidence = <String, List<String>>{};
    final strength = <String, int>{};
    void record(String planet, String why, int weight) {
      if (!_portfolio.containsKey(planet)) return;
      final reasons = houseEvidence.putIfAbsent(planet, () => <String>[]);
      if (!reasons.contains(why)) reasons.add(why);
      strength[planet] = (strength[planet] ?? 0) + weight;
    }
    for (final h in primaryHouses) {
      record(houseLord(chart, h), '$h వ భావాధిపతి', h == primaryHouses.first ? 5 : 4);
      for (final planet in chart.planets) {
        if (_houseSign(chart, h) == planet.signIndex) {
          record(planet.name, '$h వ భావంలో ఉన్న గ్రహం', 3);
        }
      }
    }
    for (final h in secondaryHouses) {
      record(houseLord(chart, h), '$h వ భావాధిపతి (సహాయక ఆధారం)', 1);
    }
    final order = strength.keys.toList()
      ..sort((a, b) {
        final result = strength[b]!.compareTo(strength[a]!);
        return result != 0 ? result : a.compareTo(b);
      });
    final options = <MehtaCareerOption>[];
    final roles = mode == MehtaCareerMode.business ? _businessRoles : _serviceRoles;
    for (final planet in order.take(4)) {
      for (final name in roles[planet] ?? const <String>[]) {
        options.add(MehtaCareerOption(
          name: name,
          planet: planet,
          planetaryReason: portfolio(planet),
          houseReasons: List<String>.unmodifiable(houseEvidence[planet]!),
          source: 'S.K. Mehta, New Dimensions in Hindu Astrology — '
              'House Portfolios / Planet Portfolios, ముద్రిత పుటలు 87–95',
        ));
      }
    }
    return List<MehtaCareerOption>.unmodifiable(options);
  }
}
