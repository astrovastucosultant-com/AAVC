// Build127: independent natal-ascendant vs Moon-ascendant evidence review.
// The house/planet rules and dignity groups are the SAME existing S.K. Mehta
// Family Inspection MF-01..MF-10; no rules imported from other systems.
// Percentages are editorial chart-evidence indexes, NOT S.K. Mehta's formula,
// objective statistical probabilities, or replacements for event-specific rules.
import 'astro_models.dart';
import 'mehta_family_house_service.dart';
import 'mehta_family_interpretation_service.dart';

class MehtaLagnaHouseComparison {
  final int house;
  final String topic;
  final int? natalPercent;
  final int? lunarPercent;
  final int natalSupporting;
  final int natalCautionary;
  final int lunarSupporting;
  final int lunarCautionary;

  const MehtaLagnaHouseComparison({
    required this.house,
    required this.topic,
    required this.natalPercent,
    required this.lunarPercent,
    required this.natalSupporting,
    required this.natalCautionary,
    required this.lunarSupporting,
    required this.lunarCautionary,
  });
}

class MehtaLagnaComparison {
  final String natalSign;
  final String? moonSign;
  final int? natalPercent;
  final int? lunarPercent;
  final int natalEvidenceHouses;
  final int lunarEvidenceHouses;
  final int natalSupporting;
  final int natalCautionary;
  final int lunarSupporting;
  final int lunarCautionary;
  final String comparativeNote;
  final List<MehtaLagnaHouseComparison> houses;

  const MehtaLagnaComparison({
    required this.natalSign,
    required this.moonSign,
    required this.natalPercent,
    required this.lunarPercent,
    required this.natalEvidenceHouses,
    required this.lunarEvidenceHouses,
    required this.natalSupporting,
    required this.natalCautionary,
    required this.lunarSupporting,
    required this.lunarCautionary,
    required this.comparativeNote,
    required this.houses,
  });
}

class MehtaLagnaComparisonService {
  static AstroChartResult _moonAsReference(
      AstroChartResult chart, PlanetPosition moon) =>
      AstroChartResult(
        julianDay: chart.julianDay,
        ayanamsaDegrees: chart.ayanamsaDegrees,
        ascendantLongitude: moon.longitude,
        planets: chart.planets,
        engineVersion: chart.engineVersion,
      );

  // Averaging an available score per distinct house prevents one house
  // repeated under multiple career/family angles from dominating the result.
  // The original per-house evidence index already regularizes very small
  // evidence counts. Zero matches must be reported as unknown, not 0 or 50%.
  static int? _meanEvidence(Iterable<int?> scores) {
    final values = scores.whereType<int>().toList(growable: false);
    if (values.isEmpty) return null;
    return (values.reduce((a, b) => a + b) / values.length).round();
  }

  static MehtaLagnaComparison evaluate(AstroChartResult chart) {
    PlanetPosition? moon;
    for (final p in chart.planets) {
      if (p.name == 'Moon') { moon = p; break; }
    }
    final lunarChart = moon == null ? null : _moonAsReference(chart, moon);
    final relation = MehtaFamilyHouseService.relations.firstWhere(
      (r) => r.id == 'self',
    );
    final rows = <MehtaLagnaHouseComparison>[];
    var natalPositive = 0, natalNegative = 0;
    var lunarPositive = 0, lunarNegative = 0;

    for (final topic in MehtaFamilyHouseService.topics) {
      final natal = MehtaFamilyInterpretationService.inspectBasicTopic(
          chart, relation, topic);
      final lunar = lunarChart == null ? null :
          MehtaFamilyInterpretationService.inspectBasicTopic(
              lunarChart, relation, topic);
      natalPositive += natal.favorable.length;
      natalNegative += natal.unfavorable.length;
      lunarPositive += lunar?.favorable.length ?? 0;
      lunarNegative += lunar?.unfavorable.length ?? 0;
      rows.add(MehtaLagnaHouseComparison(
        house: topic.offset,
        topic: topic.title,
        natalPercent: natal.evidencePercent,
        lunarPercent: lunar?.evidencePercent,
        natalSupporting: natal.favorable.length,
        natalCautionary: natal.unfavorable.length,
        lunarSupporting: lunar?.favorable.length ?? 0,
        lunarCautionary: lunar?.unfavorable.length ?? 0,
      ));
    }
    final natalCount = rows.where((r) => r.natalPercent != null).length;
    final lunarCount = rows.where((r) => r.lunarPercent != null).length;
    final natalScore = _meanEvidence(rows.map((r) => r.natalPercent));
    final lunarScore = _meanEvidence(rows.map((r) => r.lunarPercent));
    String note;
    if (moon == null) {
      note = 'చంద్రుని స్థానం లేదు; చంద్రలగ్నాన్ని లెక్కించలేము.';
    } else if (natalScore == null || lunarScore == null) {
      note = 'ఏ లగ్నం బలమైనదో నిర్ణయించేందుకు సరిపడిన నియమ ఆధారాలు లేవు.';
    } else if (chart.ascendantSignIndex == moon.signIndex) {
      note = 'జన్మలగ్నం, చంద్రలగ్నం ఒకే రాశి. రెండు సూచికలు ఒకే భావస్థితిని సూచిస్తాయి.';
    } else if (natalCount < 4 || lunarCount < 4) {
      note = 'సరిపోలిన భావాలు తక్కువగా ఉన్నాయి; ఏ లగ్నానికి ప్రాధాన్యం అని ఇప్పుడే నిర్ణయించరాదు.';
    } else if ((natalScore - lunarScore).abs() < 10) {
      note = 'రెండు సూచికల మధ్య తేడా స్వల్పంగా ఉంది; రెండు లగ్నాల నుంచీ ఫలితాన్ని పరిశీలించాలి.';
    } else if (natalScore > lunarScore) {
      note = 'ఈ యాప్ భావబల సూచికలో జన్మలగ్న ఆధారాలు ఎక్కువ. నిర్దిష్ట సంఘటనకు చంద్రలగ్నం, దశలు, మినహాయింపులు కూడా చూడాలి.';
    } else {
      note = 'ఈ యాప్ భావబల సూచికలో చంద్రలగ్న ఆధారాలు ఎక్కువ. దీని వల్ల జన్మలగ్నాన్ని రద్దు చేయము; సంఘటన నియమాన్ని రెండింటి నుంచీ పరీక్షించాలి.';
    }
    return MehtaLagnaComparison(
      natalSign: MehtaFamilyHouseService.signs[chart.ascendantSignIndex],
      moonSign: moon == null ? null : MehtaFamilyHouseService.signs[moon.signIndex],
      natalPercent: natalScore,
      lunarPercent: lunarScore,
      natalEvidenceHouses: natalCount,
      lunarEvidenceHouses: lunarCount,
      natalSupporting: natalPositive,
      natalCautionary: natalNegative,
      lunarSupporting: lunarPositive,
      lunarCautionary: lunarNegative,
      comparativeNote: note,
      houses: List.unmodifiable(rows),
    );
  }
}
