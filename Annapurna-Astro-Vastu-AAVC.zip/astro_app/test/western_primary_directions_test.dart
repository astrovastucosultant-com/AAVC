import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_primary_directions.dart';
void main(){
 test('equinox: zero longitude and latitude have RA Dec zero',(){
  final p=WesternPrimaryDirections.fromEcliptic(longitude:0,latitude:0,
   obliquity:23.4393,geographicLatitude:16);
  expect(p.rightAscension,closeTo(0,1e-9));
  expect(p.declination,closeTo(0,1e-9));
  expect(p.obliqueAscension,closeTo(0,1e-9));
 });
 test('solstitial Sun declination equals obliquity',(){
  final p=WesternPrimaryDirections.fromEcliptic(longitude:90,latitude:0,
   obliquity:23.4393,geographicLatitude:16);
  expect(p.rightAscension,closeTo(90,1e-8));
  expect(p.declination,closeTo(23.4393,1e-8));
 });
 test('circumpolar OA must be unavailable',(){
  final p=WesternPrimaryDirections.fromEcliptic(longitude:90,latitude:0,
   obliquity:23.4393,geographicLatitude:80);
  expect(p.obliqueAscension,isNull);
 });
}
