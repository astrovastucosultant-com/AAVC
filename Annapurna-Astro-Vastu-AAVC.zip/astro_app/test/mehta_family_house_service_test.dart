import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_family_house_service.dart';

void main() {
  MehtaFamilyRelation r(String id) =>
      MehtaFamilyHouseService.relations.firstWhere((x) => x.id == id);
  MehtaFamilyTopic t(String id) =>
      MehtaFamilyHouseService.topics.firstWhere((x) => x.id == id);

  test('Mehta relative reference is 10th house for father, not 9th', () {
    expect(MehtaFamilyHouseService.relativeHouse(r('father')), 10);
    expect(MehtaFamilyHouseService.relativeHouse(r('mother')), 4);
    expect(MehtaFamilyHouseService.relativeHouse(r('paternal_y')), 12);
    expect(MehtaFamilyHouseService.relativeHouse(r('paternal_e')), 8);
    expect(MehtaFamilyHouseService.relativeHouse(r('maternal_e')), 2);
    expect(MehtaFamilyHouseService.relativeHouse(r('spouse_y_spouse')), 3);
    expect(MehtaFamilyHouseService.relativeHouse(r('child_spouse')), 11);
    expect(MehtaFamilyHouseService.relativeHouse(r('father_y_spouse')), 6);
  });

  test('all 27 relatives × 12 topics resolve to a valid natal house', () {
    expect(MehtaFamilyHouseService.relations.length, 27);
    expect(MehtaFamilyHouseService.topics.length, 12);
    for (final relation in MehtaFamilyHouseService.relations) {
      for (final topic in MehtaFamilyHouseService.topics) {
        expect(MehtaFamilyHouseService.targetHouse(relation, topic),
            inInclusiveRange(1, 12));
      }
    }
    expect(MehtaFamilyHouseService.targetHouse(r('father'), t('profession')), 7);
    expect(MehtaFamilyHouseService.targetHouse(r('spouse'), t('marriage')), 1);
  });

  test('chart observations are computed separately from predicted results', () {
    const chart = AstroChartResult(
      julianDay: 2451545.0,
      ayanamsaDegrees: 24.0,
      ascendantLongitude: 2.0,
      engineVersion: 'fixture',
      planets: [
        PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 10,
            latitude: 0, speed: 1),
        PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 120,
            latitude: 0, speed: 1),
      ],
    );
    expect(MehtaFamilyHouseService.houseSign(chart, 10), 9); // Capricorn
    expect(MehtaFamilyHouseService.signLord(chart, 10), 'Saturn');
    expect(MehtaFamilyHouseService.aspecting(chart, 10).map((p) => p.name),
        contains('Saturn')); // Saturn from Aries by 10th aspect
    expect(MehtaFamilyHouseService.aspecting(chart, 9).map((p) => p.name),
        contains('Jupiter')); // Jupiter from Leo by 5th aspect
    expect(MehtaFamilyHouseService.occupants(chart, 1).map((p) => p.name),
        contains('Saturn'));
  });
}
