import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_family_house_service.dart';
import 'package:astro_app/astrology/mehta_family_interpretation_service.dart';

void main() {
  MehtaFamilyRelation relation(String id) =>
      MehtaFamilyHouseService.relations.firstWhere((r) => r.id == id);
  MehtaFamilyTopic topic(String id) =>
      MehtaFamilyHouseService.topics.firstWhere((t) => t.id == id);
  PlanetPosition planet(String name, int sign, {double degree = 10}) =>
      PlanetPosition(name: name, shortName: name.substring(0, 2),
          longitude: sign * 30.0 + degree, latitude: 0, speed: 1);
  AstroChartResult chart(int asc, List<PlanetPosition> planets) =>
      AstroChartResult(julianDay: 2451545, ayanamsaDegrees: 24,
          ascendantLongitude: asc * 30.0 + 4,
          planets: planets, engineVersion: 'test');

  test('all 27 family relations × 12 topics have audit evaluations', () {
    final c = chart(0, [planet('Saturn', 9), planet('Venus', 7),
      planet('Mars', 5), planet('Moon', 3), planet('Jupiter', 4)]);
    for (final r in MehtaFamilyHouseService.relations) {
      final reports = MehtaFamilyInterpretationService.allTopics(c, r);
      expect(reports.length, 12);
      for (final report in reports) {
        expect(report.targetHouse, inInclusiveRange(1, 12));
        expect(report.relationHouse, inInclusiveRange(1, 12));
        expect(report.checks.length, 10);
        expect(report.result.isNotEmpty, isTrue);
        expect(report.lord.isNotEmpty, isTrue);
      }
    }
  });

  test('father reference is 10th and career from father is natal 7th', () {
    final r = relation('father');
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Saturn', 9)]), r, topic('profession'));
    expect(result.relationHouse, 10);
    expect(result.targetHouse, 7);
  });

  test('debilitated Saturn aspects own Capricorn: evidence is mixed', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Saturn', 0)]), relation('father'), topic('self'));
    expect(result.targetHouse, 10);
    expect(result.lord, 'Saturn');
    expect(result.checks.firstWhere((c) => c.id == 'MF-02').matched, isTrue);
    expect(result.checks.firstWhere((c) => c.id == 'MF-08').matched, isTrue);
    expect(result.checks.firstWhere((c) => c.id == 'MF-10').matched, isTrue);
    expect(result.type, MehtaFamilyFindingType.mixed);
  });

  test('exalted Sun in Aries is strength evidence, not certain event', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Sun', 0)]), relation('self'), topic('self'));
    expect(result.checks.firstWhere((c) => c.id == 'MF-03').matched, isTrue);
    expect(result.type, MehtaFamilyFindingType.supporting);
    expect(result.result.contains('నిర్ధారణ కాదు'), isTrue);
  });

  test('lord in relative sixth is a caution from derived house', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Mars', 5)]), relation('self'), topic('self'));
    expect(result.lordRelativeHouse, 6);
    expect(result.checks.firstWhere((c) => c.id == 'MF-07').matched, isTrue);
    expect(result.type, MehtaFamilyFindingType.mixed);
  });

  test('planetary exchange is an explicit Mehta relationship', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Mars', 1), planet('Venus', 0)]),
        relation('self'), topic('self'));
    expect(result.checks.firstWhere((c) => c.id == 'MF-05').matched, isTrue);
    expect(result.relationships.any((s) => s.contains('పరివర్తన')), isTrue);
  });

  test('missing planets does not become a favorable or adverse prediction', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, []), relation('father'), topic('self'));
    expect(result.type, MehtaFamilyFindingType.undetermined);
    expect(result.lordRelativeHouse, isNull);
    expect(result.unfavorable, isEmpty);
    expect(result.favorable, isEmpty);
  });

  test('Mehta three-sign Mercury group agrees with combination registry', () {
    expect(MehtaFamilyInterpretationService.exalted['Mercury'], [10, 2, 6]);
    expect(MehtaFamilyInterpretationService.fallen['Mercury'], [4, 8, 0]);
  });

  test('Build120 money analysis covers all seven distinct money angles', () {
    final c = chart(0, [planet('Saturn', 9), planet('Venus', 1),
      planet('Mars', 7), planet('Moon', 3), planet('Jupiter', 11),
      planet('Sun', 4), planet('Mercury', 2)]);
    final result = MehtaFamilyInterpretationService.inspect(c,
      relation('father'), topic('money'));
    expect(result.angles.length, 7);
    expect(result.angles.any((a) => a.title.contains('వారసత్వం')), isTrue);
    expect(result.angles.any((a) => a.title.contains('అప్పులు')), isTrue);
    expect(result.angles.any((a) => a.title.contains('వ్యయం')), isTrue);
    expect(result.angles.any((a) => a.title.contains('ఆదాయ లాభాలు')), isTrue);
    for (final a in result.angles) {
      expect(a.referenceHouse, inInclusiveRange(1, 12));
      expect(a.referenceLord.isNotEmpty, isTrue);
      expect(a.checks.length, 10);
      expect(a.source.isNotEmpty, isTrue);
      expect(a.interpretation.isNotEmpty, isTrue);
    }
    expect(result.result.contains('7 ఉపాంశాలను'), isTrue);
  });

  test('Build120 27×12 outputs have detailed angles and consistent arithmetic', () {
    final c = chart(1, [planet('Saturn', 9), planet('Venus', 1),
      planet('Moon', 3), planet('Mars', 7), planet('Mercury', 2),
      planet('Sun', 4), planet('Jupiter', 11)]);
    var screens = 0;
    for (final r in MehtaFamilyHouseService.relations) {
      for (final report in MehtaFamilyInterpretationService.allTopics(c, r)) {
        screens++;
        expect(report.angles.length, greaterThanOrEqualTo(4));
        for (final a in report.angles) {
          final expectedTopic = topic(a.aspectTopicId);
          expect(a.referenceHouse,
            MehtaFamilyHouseService.targetHouse(r, expectedTopic));
          expect(a.checks.length, 10);
        }
      }
    }
    expect(screens, 324);
  });

  test('Build121 evidence percent never creates 100% from one match', () {
    expect(MehtaFamilyEvidenceIndex.percent(1, 0), 67);
    expect(MehtaFamilyEvidenceIndex.percent(0, 1), 33);
    expect(MehtaFamilyEvidenceIndex.percent(1, 1), 50);
    expect(MehtaFamilyEvidenceIndex.percent(0, 0), isNull);
    expect(MehtaFamilyEvidenceIndex.percent(6, 0), 88);
    expect(MehtaFamilyEvidenceIndex.percent(0, 4), 17);
  });

  test('Build121 all angles expose a bounded percent or lack of evidence', () {
    final c = chart(0, [planet('Saturn', 9), planet('Venus', 1),
      planet('Mars', 7), planet('Moon', 3), planet('Jupiter', 11),
      planet('Sun', 4), planet('Mercury', 2)]);
    for (final r in MehtaFamilyHouseService.relations) {
      for (final result in MehtaFamilyInterpretationService.allTopics(c, r)) {
        if (result.evidencePercent != null) {
          expect(result.evidencePercent!, inInclusiveRange(1, 99));
        }
        final distinct = <String>{};
        for (final angle in result.angles) {
          if (angle.evidencePercent != null) {
            expect(angle.evidencePercent!, inInclusiveRange(1, 99));
            distinct.add(angle.aspectTopicId);
          }
        }
        expect(result.scoredAngleCount, distinct.length);
      }
    }
  });

  test('Build121 missing evidence returns no percent, not zero or 50 percent', () {
    final r = MehtaFamilyInterpretationService.inspect(
        chart(0, []), relation('father'), topic('self'));
    expect(r.evidencePercent, isNull);
    expect(r.moonReview, isNull);
    for (final a in r.angles) {
      expect(a.evidencePercent, isNull);
    }
  });

  test('Build120 Moon-lagna confirmation stays separate from main result', () {
    final withMoon = chart(0, [planet('Saturn', 9), planet('Moon', 3)]);
    final result = MehtaFamilyInterpretationService.inspect(
      withMoon, relation('father'), topic('money'));
    expect(result.moonReview, isNotNull);
    expect(result.moonReview!.referenceHouse, inInclusiveRange(1, 12));
    final noMoon = MehtaFamilyInterpretationService.inspect(
      chart(0, [planet('Saturn', 9)]), relation('father'), topic('money'));
    expect(noMoon.moonReview, isNull);
  });

}

// Build121 — presentation scores are an editorial evidence index.
// These tests deliberately avoid treating the percentage as event probability.
