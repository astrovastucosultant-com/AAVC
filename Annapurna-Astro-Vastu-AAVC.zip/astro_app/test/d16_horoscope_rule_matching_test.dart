import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';
import 'package:astro_app/astrology/varga_service.dart';

AstroChartResult _chart(double shift) => AstroChartResult(
  julianDay: 2460000.5,
  ayanamsaDegrees: 24,
  ascendantLongitude: 12 + shift,
  engineVersion: 'fixture',
  planets: [
    for (final item in <(String, String, double)>[
      ('Sun', 'Su', 12), ('Moon', 'Mo', 48),
      ('Mars', 'Ma', 90), ('Mercury', 'Me', 144),
      ('Jupiter', 'Ju', 190), ('Venus', 'Ve', 240),
      ('Saturn', 'Sa', 295), ('Rahu', 'Ra', 320),
      ('Ketu', 'Ke', 140),
    ])
      PlanetPosition(name: item.$1, shortName: item.$2,
          longitude: (item.$3 + shift) % 360, latitude: 0, speed: 1),
  ],
);

void main() {
  test('D16 catalogs are preserved and contextual rules never claim matched', () {
    for (final method in D16CalculationMethod.values) {
      final rules = VargaRuleService.allFor(chart: _chart(0), factor: 16,
          d16Method: method);
      final ids = rules.map((r) => r.ruleId).toList();
      expect(ids.toSet().length, ids.length);
      for (final id in <String>[
        'D16-VEHICLE-EVIDENCE', 'D16-LUXURY-COMFORT',
        'D16-VEHICLE-DELAY', 'D16-VEHICLE-CAUTION',
        for (var i = 1; i <= 13; i++)
          'D16-VIDEO-${i.toString().padLeft(2, '0')}',
      ]) {
        expect(ids, contains(id));
      }
      for (final id in <String>[
        'D16-VIDEO-01', 'D16-VIDEO-04', 'D16-VIDEO-07',
        'D16-VIDEO-08', 'D16-VIDEO-13',
      ]) {
        final row = rules.firstWhere((r) => r.ruleId == id);
        expect(row.autoEvaluated, isFalse);
        expect(row.applicable, isFalse);
      }
    }
  });

  test('D16 relationship results match their condition and do not all auto-fire', () {
    for (final chart in <AstroChartResult>[_chart(0), _chart(67)]) {
      for (final method in D16CalculationMethod.values) {
        final rows = VargaRuleService.allFor(chart: chart,
            factor: 16, d16Method: method);
        final relevant = rows.where((x) => x.ruleId.startsWith('D16-VIDEO-') &&
            x.autoEvaluated).toList();
        expect(relevant.length, 8);
        expect(relevant.every((r) => r.applicable), isFalse,
            reason: 'A fixed generic list must not masquerade as a horoscope-specific match');
        expect(rows.every((r) => r.factor == 16), isTrue);
      }
    }
  });
  test('Guru D16 video contains all 13 distinct source rules and keeps non-matches separate', () {
  for (final method in D16CalculationMethod.values) {
    final rules = VargaRuleService.allFor(chart: _chart(26), factor: 16,
        d16Method: method);
    final video = rules.where((r) => r.ruleId.startsWith('D16-VIDEO-')).toList();
    expect(video.length, 13);
    expect(video.map((r) => r.ruleId).toSet().length, 13);
    expect(video.every((r) => r.source.contains('గురువుగారి D16 వీడియో')), isTrue);
    final matched = video.where((r) => r.autoEvaluated && r.applicable).toList();
    final unmatched = video.where((r) => r.autoEvaluated && !r.applicable).toList();
    final reference = video.where((r) => !r.autoEvaluated).toList();
    expect(matched.length + unmatched.length + reference.length, 13);
    expect(reference.every((r) => !r.applicable), isTrue);
    for (final rule in video) {
      expect(rule.rule.isNotEmpty, isTrue);
      expect(rule.inspection.isNotEmpty, isTrue);
    }
  }
});

}
