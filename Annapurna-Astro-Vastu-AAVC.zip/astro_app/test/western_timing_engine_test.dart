import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_timing_engine.dart';

void main() {
  test('whole sign profection repeats every 12 years', () {
    expect(WesternTimingEngine.annualProfectionSign(0, 0), 0);
    expect(WesternTimingEngine.annualProfectionSign(0, 12), 0);
    expect(WesternTimingEngine.annualProfectionSign(9, 5), 2);
  });
  test('symbolic and Naibod arcs are different', () {
    expect(WesternTimingEngine.symbolicPosition(10, 20), closeTo(30, 0.000001));
    expect(WesternTimingEngine.naibodPosition(10, 20), isNot(closeTo(30, .01)));
  });
  test('converse secondary mapping goes backwards', () {
    final b = DateTime.utc(2000, 1, 1);
    final e = DateTime.utc(2020, 1, 1);
    expect(WesternTimingEngine.secondaryDate(b, e, converse: true).isBefore(b), true);
    expect(WesternTimingEngine.secondaryDate(b, e).isAfter(b), true);
  });
  test('solar arc wraps longitudes', () {
    expect(WesternTimingEngine.solarArcPosition(
      natalBody: 359, natalSun: 350, progressedSun: 355), closeTo(4, 1e-7));
  });
  test('primary directions refuses placeholder computation', () {
    expect(() => WesternTimingEngine.primaryDirectionsNotReady(),
      throwsUnsupportedError);
  });
}
