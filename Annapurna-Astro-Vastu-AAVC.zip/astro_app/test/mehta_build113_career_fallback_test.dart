import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/mehta_combination_service.dart';
import 'package:astro_app/astrology/d10_final_profession_engine.dart';

void main() {
  test('legacy Mehta career folders are combined, other folders preserved', () {
    expect(MehtaCombinationService.dashboardFolderLabel('ఉద్యోగం / వృత్తి'), 'ఉద్యోగం / వృత్తి');
    expect(MehtaCombinationService.dashboardFolderLabel('వృత్తి / ఉద్యోగం'), 'ఉద్యోగం / వృత్తి');
    expect(MehtaCombinationService.dashboardFolderLabel('సంతానం / విద్య'), 'సంతానం / విద్య');
    final career = MehtaCombinationService.rules.where((rule) =>
      MehtaCombinationService.dashboardFolderLabel(rule.folderLabel) == 'ఉద్యోగం / వృత్తి');
    expect(career.length, greaterThanOrEqualTo(6));
  });

  test('D10 profession families exist even without Mehta occupation matches', () {
    expect(D10FinalProfessionEngine.professionFamilies.length, greaterThanOrEqualTo(20));
    expect(D10FinalProfessionEngine.professionFamilies.any((c) =>
      c.name == 'Commercial / Business / Entrepreneurship'), isTrue);
    expect(D10FinalProfessionEngine.professionFamilies.any((c) =>
      c.name == 'Engineering / Technical'), isTrue);
  });
}
