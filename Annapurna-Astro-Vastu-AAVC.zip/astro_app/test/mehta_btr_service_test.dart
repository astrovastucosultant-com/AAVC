import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';
import 'package:astro_app/models/birth_data.dart';

void main() {
  final natal = BirthData(
    name: 'Example',
    localDateTime: DateTime(1985, 7, 22, 10, 0, 0),
    place: 'Guntur', latitude: 16.3, longitude: 80.44,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
  );

  MehtaBtrEvent event(String id, DateTime date) =>
      MehtaBtrEvent(ruleId: id, occurredAt: date);

  test('BTR requires 3 distinct dated events and 2 kinds', () {
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(2008, 6, 3)),
      event('M01', DateTime(2010, 1, 4)),
    ], natal.localDateTime), isNotNull);
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(2008, 6, 3)),
      event('M01', DateTime(2010, 1, 4)),
      event('M01', DateTime(2012, 4, 6)),
    ], natal.localDateTime), isNotNull);
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(2008, 6, 3)),
      event('M06', DateTime(2010, 1, 4)),
      event('M11', DateTime(2012, 4, 6)),
    ], natal.localDateTime), isNull);
  });

  test('reject event before birth, future event, and duplicated day', () {
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(1980, 6, 3)),
      event('M06', DateTime(2010, 1, 4)),
      event('M11', DateTime(2012, 4, 6)),
    ], natal.localDateTime), isNotNull);
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(2008, 6, 3)),
      event('M06', DateTime(2008, 6, 3)),
      event('M11', DateTime(2012, 4, 6)),
    ], natal.localDateTime), isNotNull);
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(2008, 6, 3)),
      event('M06', DateTime(2010, 1, 4)),
      event('M11', DateTime(2099, 4, 6)),
    ], natal.localDateTime), isNotNull);
  });

  test('required primary places prevent an inflated perfect match', () {
    expect(MehtaBtrService.primaryEvidenceShare(
        ['Mars', 'Venus'], ['Mars', 'Venus', 'Jupiter'], 3),
        closeTo(2 / 3, 0.001));
    expect(MehtaBtrService.primaryEvidenceShare(
        ['Mars', 'Venus'], ['Mars', 'Venus', 'Mars'], 3), 1);
    expect(MehtaBtrService.primaryEvidenceShare(
        ['Mars', 'Venus'], ['Jupiter', 'Sun', 'Moon'], 3), 0);
    expect(MehtaBtrService.primaryEvidenceShare(
        ['Mars', 'Venus'], [], 3), 0);
  });

  test('date-only event today is not a fictitious future noon', () {
    final today = DateTime.now();
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(2008, 6, 3)),
      event('M06', DateTime(2010, 1, 4)),
      event('M11', DateTime(today.year, today.month, today.day, 12)),
    ], natal.localDateTime), isNull);
  });

  test('same-day date-only event at birth is not reliable evidence', () {
    expect(MehtaBtrService.validateEvents([
      event('M01', DateTime(1985, 7, 22, 12)),
      event('M06', DateTime(2010, 1, 4)),
      event('M11', DateTime(2012, 4, 6)),
    ], natal.localDateTime), isNotNull);
  });

  test('unknown event hour is sampled, known hour is not', () async {
    const fake = AstroChartResult(
      julianDay: 2450000, ayanamsaDegrees: 23,
      ascendantLongitude: 12, engineVersion: 'unit-test',
      planets: [PlanetPosition(name: 'Moon', shortName: 'Mo',
          longitude: 45, latitude: 0, speed: 13)],
    );
    final known = MehtaBtrEvent(ruleId: 'M01',
      occurredAt: DateTime(2008, 6, 3, 9, 30), timeKnown: true);
    final unknown = MehtaBtrEvent(ruleId: 'M01',
      occurredAt: DateTime(2008, 6, 3, 12), timeKnown: false);
    final candidate = await MehtaBtrService.scoreCandidate(
      natal: natal,
      candidateBirthTime: natal.localDateTime,
      events: [known, unknown],
      chartCalculator: (_) async => fake,
    );
    expect(candidate.evidence[0].sampledInstants, 1);
    expect(candidate.evidence[1].sampledInstants, 3);
    for (final row in candidate.evidence) {
      expect(row.minimumShare, lessThanOrEqualTo(row.combinedShare));
      expect(row.maximumShare, greaterThanOrEqualTo(row.combinedShare));
      expect(row.combinedShare, inInclusiveRange(0, 1));
    }
  });

  test('matching duplicates do not exceed 100% evidence', () {
    expect(MehtaBtrService.lordEvidenceShare(
      ['Mars', 'Mars', 'Venus'], ['Mars']), closeTo(0.5, 0.001));
    expect(MehtaBtrService.lordEvidenceShare(
      ['Mars', 'Venus'], ['Mars', 'Venus', 'Mars']), 1);
  });

  test('multi-event BTR search keeps ambiguity when charts are identical', () async {
    const fake = AstroChartResult(
      julianDay: 2450000, ayanamsaDegrees: 23,
      ascendantLongitude: 12, engineVersion: 'unit-test',
      planets: [PlanetPosition(name: 'Moon', shortName: 'Mo',
          longitude: 45, latitude: 0, speed: 13)],
    );
    final report = await MehtaBtrService.search(
      natal: natal,
      plusMinusMinutes: 30,
      events: [
        event('M01', DateTime(2008, 6, 3)),
        event('M06', DateTime(2010, 1, 4)),
        event('M11', DateTime(2012, 4, 6)),
      ],
      chartCalculator: (_) async => fake,
    );
    expect(report.testedTimes, greaterThan(20));
    expect(report.best, isNotNull);
    expect(report.distinguishable, isFalse);
    expect(report.rangeStart, isNotNull);
    expect(report.rangeEnd, isNotNull);
    expect(report.best!.evidence, hasLength(3));
    for (final item in report.best!.evidence) {
      expect(item.combinedShare, inInclusiveRange(0, 1));
    }
  });
}
