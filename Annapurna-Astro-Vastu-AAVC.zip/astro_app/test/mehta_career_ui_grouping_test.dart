import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_career_options_service.dart';
import 'package:astro_app/screens/mehta_career_options_panel.dart';

const _positions = <PlanetPosition>[
  PlanetPosition(name:'Sun',shortName:'Su',longitude:10,latitude:0,speed:1),
  PlanetPosition(name:'Moon',shortName:'Mo',longitude:44,latitude:0,speed:1),
  PlanetPosition(name:'Mars',shortName:'Ma',longitude:94,latitude:0,speed:1),
  PlanetPosition(name:'Mercury',shortName:'Me',longitude:167,latitude:0,speed:1),
  PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:241,latitude:0,speed:1),
  PlanetPosition(name:'Venus',shortName:'Ve',longitude:197,latitude:0,speed:1),
  PlanetPosition(name:'Saturn',shortName:'Sa',longitude:319,latitude:0,speed:1),
];

void main() {
  testWidgets('Business grouped by one common planetary evidence', (tester) async {
    final chart = AstroChartResult(
      julianDay:2460000, ayanamsaDegrees:24,
      ascendantLongitude:10, planets:_positions, engineVersion:'test',
    );
    await tester.pumpWidget(MaterialApp(home: Scaffold(body:
      MehtaCareerOptionsPanel(chart:chart),
    )));
    await tester.tap(find.text('వ్యాపారం → అనుకూల వ్యాపారాల జాబితా'));
    await tester.pumpAndSettle();
    expect(find.byType(ExpansionTile), findsWidgets);
    // A single planet is shown once as a grouped category, not once per job.
    final actual = MehtaCareerOptionsService.evaluate(chart,MehtaCareerMode.business);
    final planets = actual.map((x) => x.planet).toSet();
    expect(find.byType(ExpansionTile), findsNWidgets(planets.length));
  });
}
