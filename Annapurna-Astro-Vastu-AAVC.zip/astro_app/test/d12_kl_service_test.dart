import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/d12_kl_service.dart';
import 'package:astro_app/astrology/varga_service.dart';

void main() {
  const p = <PlanetPosition>[
    PlanetPosition(name:'Sun',shortName:'Su',longitude:29.0,latitude:0,speed:1),
    PlanetPosition(name:'Moon',shortName:'Mo',longitude:55.0,latitude:0,speed:1),
    PlanetPosition(name:'Mars',shortName:'Ma',longitude:87.0,latitude:0,speed:1),
    PlanetPosition(name:'Mercury',shortName:'Me',longitude:112.0,latitude:0,speed:1),
    PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:136.0,latitude:0,speed:1),
    PlanetPosition(name:'Venus',shortName:'Ve',longitude:163.0,latitude:0,speed:1),
    PlanetPosition(name:'Saturn',shortName:'Sa',longitude:191.0,latitude:0,speed:1),
    PlanetPosition(name:'Rahu',shortName:'Ra',longitude:217.0,latitude:0,speed:-1),
    PlanetPosition(name:'Ketu',shortName:'Ke',longitude:37.0,latitude:0,speed:-1),
  ];
  const chart=AstroChartResult(julianDay:2460000.0,ayanamsaDegrees:24,
      ascendantLongitude:42.0,planets:p,engineVersion:'fixture');

  test('KL anchor uses Jaimini AK Navamsa, D12 lagna does not change', () {
    final d12=VargaService.calculate(chart,12);
    final result=D12KlService.analyze(chart,d12);
    final jaimini=JaiminiService.calculate(chart);
    expect(result.atmakaraka,'Sun');
    expect(result.klSign,jaimini.karakamsaSignIndex);
    expect(result.klSign,VargaService.signForLongitude(29.0,9));
    expect(result.d12Sign,d12.ascendantSignIndex);
    expect(result.signForHouse(1),result.klSign);
    expect(result.signForHouse(12),(result.klSign+11)%12);
    expect(result.houseForSign(result.signForHouse(11)),11);
  });

  test('All percentages come from explicit counts; pending excluded from matches', () {
    final x=D12KlService.analyze(chart,VargaService.calculate(chart,12));
    expect(x.allChecks,13);
    expect(x.tested,10);
    expect(x.pending,3);
    expect(x.matched,lessThanOrEqualTo(x.tested));
    expect(x.evaluatedPercent,77);
    expect(x.matchPercent,(100*x.matched/x.tested).round());
    expect(x.favorableMatched+x.cautionMatched,x.matched);
    expect(x.checks.any((r)=>r.ruleId=='D12-KL-EST-04'),isTrue);
    expect(x.checks.any((r)=>r.ruleId=='D12-KL-LONG-01'&&r.matched==null),isTrue);
  });

  test('Degree tie prevents claims of evaluated KL matches', () {
    final tied=AstroChartResult(julianDay:chart.julianDay,
      ayanamsaDegrees:chart.ayanamsaDegrees,ascendantLongitude:42.0,
      planets:[
        ...p.where((x)=>x.name != 'Moon'),
        const PlanetPosition(name:'Moon',shortName:'Mo',longitude:59.0,latitude:0,speed:1),
      ],engineVersion:'fixture');
    final x=D12KlService.analyze(tied,VargaService.calculate(tied,12));
    expect(x.degreeTie,isTrue);
    expect(x.tested,0);
    expect(x.matched,0);
    expect(x.checks.every((x)=>x.matched==null),isTrue);
  });
}
