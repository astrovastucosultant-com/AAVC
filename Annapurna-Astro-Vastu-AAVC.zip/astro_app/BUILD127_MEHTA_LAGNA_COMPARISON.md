# Build127 — S.K. Mehta birth-Lagna and Moon-Lagna comparison

Scope: **S.K. Mehta tab only**. All pre-existing D7, D10, D12, KP and other unrelated modules are preserved.

## UI
- At the top of S.K. Mehta tab show **జన్మలగ్న బలం %** and **చంద్రలగ్న బలం %** independently, with signs and evidence coverage out of 12 houses.
- Expand 12 houses to inspect independent supportive / cautionary evidence per house, with two evidence indexes side-by-side.
- Expand 'how calculated / sources' to inspect the editorial percentage calculation and its limitations.
- In Family Analysis, each selected life topic now additionally shows both natal and Moon-based *single-topic* evidence indexes; the pre-existing multi-angle total is unchanged.

## Evidence calculation
- Uses exclusively the existing Mehta Family MF-01..MF-10 house evidence checks (own sign, lord's aspect, chart's dignity group, exchange, lord in 6/8/12, etc.) from the same birth chart.
- The natal reference is the actual natal ascendant; Moon reference temporarily counts the Moon sign as first house with planetary positions unchanged.
- Each of the 12 houses is counted **once**, regardless of repeated related topics.
- For each house with `A` supporting and `B` cautionary matched checks: `round(100*(A+1)/(A+B+2))` (existing Build121 regularized evidence index).
- The Lagna index is the arithmetic mean of available house scores. House with **no matched check** has no percentage, not 0% or 50%.
- Neither score is a probability, nor does their sum have to equal 100%. No automatic replacement of birth ascendant as reference for unrelated Mehta combination rules.
- A higher score only becomes a *provisional comparative indication* if at least 4 houses have evidence in both references and the absolute difference is at least 10 percentage points; these thresholds are UI editorial choices, **not** Mehta-authored doctrine.

## Sources and guardrails
- S.K. Mehta: *New Dimensions in Hindu Astrology*, printed pages 26–28, 87–95, 100–109. *Synchronization of Period*, printed pages 12–18 for independent Moon-ascendant checking in event analysis.
- The source volumes do not establish this exact numerical index. Thus it must not be labeled an S.K. Mehta percentage formula or predict exact events / medical results.
- No rules from BPHS, Ashtakavarga, D10 or KP were merged into this Mehta-only calculation.

## Local static checks / build
- Source content, cross-reference imports, 12-house enumeration, and ZIP integrity audited.
- Flutter analyzer/test/release APK **not available locally**; next GitHub Actions run must compile and test; on-device verification remains necessary.
