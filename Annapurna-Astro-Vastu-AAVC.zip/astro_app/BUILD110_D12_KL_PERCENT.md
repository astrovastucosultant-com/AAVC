# Annapurna Astro Vastu v1.4.110 — D12 KL reference, percentages

## What changed

- The **original Parashari D12 Lagna** chart is preserved. A blue `KL` marker now overlays the **AK Navamsa / Karakamsa sign** on the original D12 chart.
- A second chart shows unchanged D12 planet positions with **KL as the counting reference** (`KL` badge, house 1).
- KL house table: 12 relative houses with sign, lord, planet occupants.
- A separate `D12KlService` evaluates 10 reproducible structural tests, holds 3 source items as pending, and displays IF -> per-chart evidence -> source THEN -> printed page. No extra outcomes are injected into the legacy D12 matcher or doubled as matched results.
- Ratios: `evaluated / 13`, `matched / evaluated`, `favorable matches / (favorable+caution matches)`. The last ratio is **only a proportion of matched directional checks**, NOT success probability, and cannot be interpreted as assurance of a life outcome.
- AK degree ties block automatic KL matching, leaving rules pending.
- Sensitive parent longevity evidence is shown as a house mapping only. No years of death or life-span probabilities.
- Original 59-rule/20-example JSON and other varga services are unchanged.

## Source boundary (important)

The user-supplied **Saral Jyotish Part VII, Chapter 9, printed pp.293-340** shows charts titled `Dwadashamsha with KL as lagan` but **does not explicitly define KL's independent computational formula** in this excerpt. This implementation openly chooses the Jaimini Karakamsa (AK's D9 sign), using the *already existing* `JaiminiService` algorithm. This is a **documented implementation convention**, and must not be presented as proven by the excerpt. Printed chart examples are visual cross-check references, not independently recalculated ephemerides.

Rules: GK/trik relation and blessing (p293/p299), childhood 2nd/4th house comparison (p299-300), Sun/Moon parent relation (p307), AK care (p314), inheritance eighth lord / nodes (p323-324). Subjective KL strength, cyclical D12 and longevity forecasting remain pending. Classical graha aspects are 7th for classical planets, Mars 4/8, Jupiter 5/9, Saturn 3/10; node special aspects not invented.

## Version / verification

- Version: `1.4.110+110`.
- New files: `lib/astrology/d12_kl_service.dart`, `lib/screens/d12_kl_panel.dart`, `test/d12_kl_service_test.dart`.
- Changed: `lib/screens/chart_screen.dart`, `pubspec.yaml`.
- Flutter/Dart SDK is **not available** in this working container. `flutter test` and `flutter build apk` **not run**. Do not claim APK or runtime validation. Run GitHub Actions build after uploading the source ZIP, then check the new run's artifacts.
- This source ZIP does not push or overwrite the user's GitHub branch.
