# Build140 — Marriage Final Report / Save / Share
Version: 1.4.163+163

Implemented:
- Report generated from selected first and second horoscope.
- D1 / D9 ascendant sign references for both charts.
- Each chart's existing D7 Ketu divorce rule 35 evaluation and D9 evidence, explicitly labelled as indicators, not certainty.
- All ten two-chart source entries with rule ID and page, explicitly marked as not fully evaluated.
- On-screen scrollable selectable report, Copy, Saved Reports (existing storage) and Android Share (existing share_plus).
- Does not replace or modify the rule calculations.

Limitations:
- No PDF export in this build. Share transmits formatted plain text.
- Unverified marriage rules do not result in a fabricated marriage matching percentage or verdict.
- Flutter compiler and Android installation not run in this environment.
