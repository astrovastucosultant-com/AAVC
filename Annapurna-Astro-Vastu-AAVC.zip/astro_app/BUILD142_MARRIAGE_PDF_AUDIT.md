# Build142 v1.4.165 — Marriage Final Report PDF Audit

Base: v1.4.164 source.
Changes: `chart_screen.dart` (structured color-coded preview, counts of matched/caution/undetermined source rules; PDF Save/Print and Share PDF actions), new `marriage_pdf_report_service.dart` (Unicode Telugu is rendered with the Android/Flutter text rasterizer and assembled as multi-page A4 PDF; no font binary distributed), `pubspec.yaml` (pdf + printing; version 1.4.165+165).

- Groom and bride D1/D9, D7 rule 35 and original ten printed-rule evaluations stay present.
- Original rule inputs, source notes and classifications remain unchanged.
- PDF preview/save through Android Print dialog and share through system share sheet.
- Counts are evidence counts, NOT a compatibility percentage.
- Incomplete printed-table conclusions remain unclassified; not invented.
- Package dependencies newly added: `pdf:^3.11.3`, `printing:^5.14.2`; network package resolution required in GitHub CI.
- Flutter compile/mobile PDF rendering: NOT tested (Flutter SDK unavailable here).
- Gujarati/Telugu fallback PDF page rendering requires Android system font; test real Telugu multi-page print on a phone.
