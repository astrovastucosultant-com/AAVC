# Build126 — BTR compile fix

- Based on v1.4.125 Multi-Event BTR source.
- Build #107 (run 38329586853) failed during Flutter compilation at `lib/screens/mehta_btr_screen.dart` lines 515 and 518.
- Replaced `child:` with supported `label:` for `OutlinedButton.icon` and `FilledButton.icon`.
- Upgraded app version from `1.4.125+125` to `1.4.126+126`.
- BTR event entry, multi-event search, analysis services, existing features and modules are unchanged.
- ZIP integrity and source-level regression checks passed.
- Flutter compilation and APK run are **not** verified yet; next GitHub Actions build must validate them.
