# Build129 — Mehta Event Timing: Marriage / Children / Economic Gain

## Scope

User-requested rule display and navigation for events from the three supplied S.K. Mehta scans. Source-first catalogue only; no unverified date-of-event predictor has been added.

### Screen location

S.K. Mehta tab > "Mehta — ఈ దశలో ఏ సంఘటనకు సూచన?" > event result card > chart verification steps > rule / printed book page. The 'ఈ సంఘటన దశా పరిశీలన ఎంచుకోండి' button selects the pre-existing M01, M06, or M03 timing engine in the section below.

### Evidence and limits

- Marriage: Synchronization of Period pp. 12–15 and New Dimensions p.232; uses event rule M01 (1/7/12).
- Childbirth (first): Synchronization of Period pp.27–29 and New Dimensions pp.170–173, existing M06 (1/5/9).
- Childbirth (second): same M06 reused for a chronologically separate observation; no invented specific second-child date rule. New Rules and Combinations pp.162–168 discuss some child ordering *not timing*.
- Economic gain: Synchronization of Period pp.23–25; New Dimensions pp.230–231; New Combinations p.143. Existing M03 performs the 2nd-lord *primary period* check, not comprehensive 9th/11th matching. This distinction is written in-screen.

These are classical astrology source claims, not validated probabilities. First and second child calculations are not asserted as distinct automated chronological forecasts. Source scan glyph tables require direct consultation before declaring exact dates.

## Changed files vs v1.4.128

- `lib/screens/chart_screen.dart`: source-rule panel in Mehta view; selection callback and stale year-audit reset.
- `pubspec.yaml`: `1.4.129+129`.

## New files

- `lib/astrology/mehta_timing_source_rules.dart`
- `lib/screens/mehta_timing_source_rules_panel.dart`
- `test/mehta_timing_source_rules_test.dart`
- This document.

## Test conditions

Static structural tests and ZIP integrity can run in the current workspace; the Flutter SDK is not installed here. Compile and on-device interactive tests must be confirmed by GitHub Actions / APK installation.
