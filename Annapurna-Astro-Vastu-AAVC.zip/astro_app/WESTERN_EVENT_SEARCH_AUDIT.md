# Western Event Timing Search v1.4.160

- Added a separate event-timing selection panel to Western Timing tab.
- Event categories: marriage, children, careers, assets, health and other event types.
- Custom From and To date (through year 2200) and configurable sample cadence: 1,3,7,15,30,90,180,365 days.
- Maximum 400 computed date samples per search to protect device performance; the range itself is not restricted to a short window.
- Results show closest planetary natal contacts with orbs for sampled dates, NOT validated event dates or event probability. Event-specific prediction rules and full Primary Directions are NOT implemented.
- New code in lib/screens/western_timing_tab.dart; pubspec bumped to 1.4.160+160.
- ZIP file integrity checked. Flutter compile and runtime checks NOT performed.
