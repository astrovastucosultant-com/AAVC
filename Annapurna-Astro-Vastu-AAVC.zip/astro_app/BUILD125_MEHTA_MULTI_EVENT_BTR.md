# Build125 — S.K. Mehta multi-event BTR audit and exploratory search

- Source basis: S.K. Mehta *Synchronization of Period* and previously included master event registry; no Jaimini, KP, or Ashtakavarga rules are imported into this screen.
- Audit: earlier Build124 only scans **one past event year**; it is **not BTR** and cannot find birth time from multiple historical events.
- New UI: 5 initial event rows; add/remove to 30, mandatory date, optional HH:MM:SS event time, notes, automatic local storage, explicit Search action.
- Validation: at least 3 different dated events and 2 event kinds; recommend 5–10 independent events with documentary confirmation.
- Search: recompute birth chart for each candidate time around original (±30/60/120/360/720 minutes); compare event-date AD, PD and Sukshma Mehta lord evidence for both Vimshottari and Tribhagi plus Moon-ASC confirmation.
- Results: per-event evidence match percentage (NOT prediction probability); candidate times, ambiguous/time band, supporting lords, ability to copy report. Apply time only after positive confirm and distinguishable ranking; original birth time preserved.
- This is an *experimental evidence-ranking approach*, not the complete, scientifically validated original Mehta BTR algorithm. It does not produce guaranteed precise birth seconds or guarantee an event happened; second-level search refinement must not be interpreted as second-level accuracy.
- Deliberately excluded sensitive death/accident event prediction from the multi-event search.
- Files changed: `pubspec.yaml`, `lib/screens/chart_screen.dart`; new `lib/screens/mehta_btr_screen.dart`, `lib/astrology/mehta_btr_service.dart`, tests.
- Not changed: D7, D10, D12, standard Mehta combinations, DashaService formulas, original chart storage, existing family analysis.
- Checks required after upload: Flutter analyzer, flutter test, GitHub Android APK build, on-device date/time and saved-data QA.
