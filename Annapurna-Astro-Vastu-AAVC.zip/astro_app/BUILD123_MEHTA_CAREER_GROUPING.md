# Build123 – S.K. Mehta business/service list clarity

## Issue
Build104 screenshots show several occupations based on exactly one underlying planetary-house relation. They are examples of a broad occupation field, NOT separate confirmed horoscope results. Individual "success probabilities" must not be invented.

## Fix
- Business and service lists group choices by their shared supporting planet/portfolio.
- Tap planetary field to expand examples; tap example for horoscope evidence; then tap rule/source.
- Display explanatory note that group examples share evidence.
- Retain the original business-vs-service house portfolio logic, 7/6,10 and 2/11 supportive houses.
- Do not import D10 or outside authors into this S.K. Mehta view.
- Existing modules and astrology calculations remain unchanged.

## Validation
Static source/ZIP checks only. Flutter compilation and on-device UI tests must be confirmed in GitHub Actions and the APK.
