# Build128 — BTR Deep Audit (v1.4.128)

## Scope and release status
Input: Build127 source ZIP v1.4.127, 462 original files. BTR-only changes; existing D7/D10/D12, Mehta combination/family/lagna systems and chart recalculation callback remain byte-for-byte unchanged. No files deleted.

## Confirmed fixes
1. Unknown event clock time: the prior code silently scored at 12:00. It now samples 00:00, 12:00, 23:59:59 on the supplied historical date, reports the minimum/maximum score, and uses the average rather than a favourable maximum. Event time known: the entered HH:MM:SS is used unchanged. Three samples are an approximation, NOT an exhaustive continuous interval scan.
2. Primary AD/PD/Sukshma evidence: now checks how many of those three actual dasha places are in the expected lord group. A rule requiring three places does not receive 100% for two matching places. The score is still an exploratory application-defined evidence index, NOT a Mehta-original probability.
3. Event validation: date-only records compare calendar days, not imaginary noon. Birth-day date-only events are rejected because their ordering relative to birth is unknown. Distinct-date, event-type, future-event and 3-30 count constraints preserved.
4. Asynchronous Saved Events restoration cannot silently overwrite in-progress user edits or search. Inputs are disabled while searching; search state is set BEFORE async local save. Old search results remain invalidated after changes.
5. UI event report: distinguishes exact HH:MM:SS entry from date-only, shows daily score variation, adds rule ID/source and per-event dasha comparison to copied report.
6. Candidate marked distinguishable only if at least 3 events have at least 50% internal evidence, in addition to existing rank/ambiguity constraints. Not proof of an exact second.
7. Existing confirm-before-apply, 30 max event rows, Saved Events, 3/5/10 event guidance, historical Search range, BTR difference HH:MM:SS preserved.

## QA and limits
- Static source checks and bytewise untouched-module comparison: pass.
- Dart/Flutter SDK is not installed in the working container. Flutter analyzer, flutter test, device-run and GitHub release APK build are NOT performed here; next GitHub Actions build is required.
- Newly added Flutter test cases (not executed) cover partial three-place match, same-day unknown event time, and known-vs-unknown timing sampling.
- 3 instants do not determine every sub-day dasha transition; exact event place/time-zone/DST interpretation needs external confirmation. BirthData uses a fixed natal time-zone offset; event place changes are not modelled independently.
- Event suitability, actual Mehta right/wrong glyph tables, prior-life/natal promise, document confidence, ephemeris errors, and time-dependent yogas are not exhaustively evaluated. Avoid calling this a complete traditional Mehta BTR algorithm.
- Time of birth cannot be validated to seconds using dasha-lord coincidence alone; many birth times may tie and a real-world verification is required.
- Never treat a relative match index % as event probability or birth-time accuracy.

## Next action
Upload `Annapurna-Astro-Vastu-v1.4-audited-fixed.zip` to the same GitHub file location and run workflow. If it compiles, test 2008 marriage with 2+ additional independently dated events, including at least one precisely timed event; check leading candidate AND competing window before applying.
