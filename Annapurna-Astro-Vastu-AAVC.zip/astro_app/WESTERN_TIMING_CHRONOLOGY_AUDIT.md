# Western Timing date ordering fix

- Year-wise is the default: chronological ascending dates.
- Strongest Match displays the smallest event-filtered orb first.
- Both display modes use the same top 40 orb-ranked samples; no event dates outside the selected From–To window are introduced.
- Fixed an infinite loop risk when an unsupported Telugu event type is selected (the prior `continue` skipped the loop date increment).
- ZIP CRC/integrity verified. Flutter/Dart SDK unavailable; APK compilation not verified.
- Do not replace the stable Build #144 until GitHub Actions succeeds.
